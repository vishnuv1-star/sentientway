# BI/MARS Incident Intelligence Assistant

BI/MARS Incident Intelligence is a read-only command-line service for
understanding Michaels Retail BI/MARS Freshservice incidents before technical
investigation starts.

It retrieves a Freshservice ticket, cleans and preserves its source context,
then passes the full text and visual context to the locally running
`nuextract3` model through LM Studio's OpenAI-compatible API. The application
talks only to the local LM Studio API at `127.0.0.1:1234` and does not call a
hosted model API, Ollama, or Hugging Face Hub.

## What is implemented

- Freshservice API v2 ticket retrieval with requester data, custom fields, and
  paginated conversations. Conversation messages retain their order, author,
  timestamp, and message body for flow-aware extraction.
- Backend-only Freshservice API-key authentication.
- Read-only API behavior. The service does not update tickets, post replies,
  add notes, change status, or change assignments.
- Local LM Studio text and vision extraction using the loaded `nuextract3`
  model through the OpenAI-compatible API.
- Multimodal extraction for Freshservice screenshots and PDF pages. PDFs are
  rendered to images before being passed to the local model.
- Schema-validated JSON extraction with a bounded strict retry.
- Evidence-bearing extraction output with source and supporting text.
- Domain-aware incident understanding for Merchandising, TAM, Warehouse,
  BI Reports, Loyalty, Store Operations, and other areas.
- Deterministic store, manager-email, report-date, SCO/EOD, missing-report,
  multiple-store, and contextual-SKU rules when those details apply.
- Conditional required fields and focused clarification questions.
- Shared deadlines, bounded retries, rate-limit handling, and duplicate-analysis
  protection. Ticket and attachment data are not cached by the CLI.
- Structured partial-result errors when Freshservice or the configured model
  provider is unavailable.

## Quick start

### 1. Install dependencies

Use 64-bit Python 3.11 on the deployment machine.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
```

For development and tests, install `requirements-dev.txt` instead. It includes
the runtime requirements and `pytest`.

### 2. Verify the local LM Studio model

The production runtime expects LM Studio to be running with `nuextract3`
loaded:

```powershell
py .\model_status.py
```

The expected endpoint is `http://127.0.0.1:1234/v1`. Verify it directly:

```powershell
Invoke-RestMethod http://127.0.0.1:1234/v1/models
```

No Hugging Face login, token, bucket, or model download is required.

### 3. Configure backend settings

Copy `.env.example` only when starting a new environment:

```powershell
Copy-Item .env.example .env
```

Set these values in `.env`:

```dotenv
FRESHSERVICE_URL=https://your-domain.freshservice.com
FRESHSERVICE_API_KEY=server-side-key
FRESHSERVICE_WORKSPACE_ID=2
MODEL_PROVIDER=lmstudio
MODEL_NAME=nuextract3
LMSTUDIO_MODEL=nuextract3
LMSTUDIO_BASE_URL=http://127.0.0.1:1234/v1
LMSTUDIO_API_KEY=lm-studio
LMSTUDIO_TIMEOUT_SECONDS=120
LMSTUDIO_MAX_TOKENS=1024
LMSTUDIO_REASONING_EFFORT=none
```

The application requires `FRESHSERVICE_URL` and `FRESHSERVICE_API_KEY`.
`MODEL_PROVIDER=lmstudio` is the only supported provider.

Never commit `.env`, include it in an archive, or put credentials in ticket
text or generated output.

### 4. Analyze an incident

The command prints only incident entity/value JSON to standard output. It does
not start a local web server.

For screenshots and PDFs, the backend downloads Freshservice attachments into
memory only, renders PDF pages to images in memory, and sends the visual
evidence to the local NuExtract3 model together with the complete ordered
conversation. Attachment bytes are not written to disk, cached, or included
in command-line output, and the buffers are cleared after analysis.

```powershell
py analyze_incident.py INC-976902
```

Before the first analysis, run `py .\model_status.py` to confirm that LM Studio
can see the model.

A successful analysis exits with code `0`. A failed or incomplete analysis
still returns the incident facts that were retrieved and exits with code `1`.
Missing input exits with code `2`.

## Structured output

The CLI JSON response contains `incident_number` and an `entities` array. Each
entity is a direct one-field object. The model chooses the incident-specific
fields; BI incidents and Loyalty incidents do not receive the same field list.
Incident/API metadata such as Freshservice ticket IDs, display IDs, and status
are not exposed. Entities that are not present in the ticket or conversation are
omitted rather than emitted as `null`.
For example:

```json
{
  "incident_number": "INC-974421",
  "entities": [
    {
      "requester_email": "amy331@michaels.com"
    },
    {
      "priority": "2"
    },
    {
      "store_number": "2048"
    },
    {
      "report_business_date": null
    }
  ]
}
```

For a Loyalty incident, the model may instead return fields such as
`member_id`, `transaction_id`, `points_or_rewards_issue`, and
`transaction_date`, only when they are relevant.

The full internal assessment still uses evidence and validation, but those
fields are not printed by the CLI.

The CLI returns only the entities for the selected BI/MARS category. It does
not mix SCO EOD, Lighthouse Sales, and Rewards fields. If the category cannot
be identified reliably, no category-specific fields are emitted rather than
guessing a category.

Possible readiness statuses:

- `NEEDS_CLARIFICATION`
- `INVALID_DATA`
- `CONFLICTING_INFORMATION`
- `READY_FOR_INVESTIGATION`
- `ANALYSIS_FAILED`
- `ANALYSIS_TIMED_OUT`

The ticket creation timestamp is never used as a report business date. Store
numbers and SKU IDs remain strings so leading zeroes are preserved.

## Configuration reference

| Variable | Default | Purpose |
| --- | --- | --- |
| `FRESHSERVICE_URL` | none | Freshservice account base URL |
| `FRESHSERVICE_API_KEY` | none | Backend-only Freshservice API key |
| `FRESHSERVICE_WORKSPACE_ID` | none | Optional workspace filter |
| `MODEL_PROVIDER` | `lmstudio` | The only supported model provider |
| `MODEL_NAME` | `nuextract3` | Configured model identity |
| `LMSTUDIO_MODEL` | `nuextract3` | Loaded LM Studio model |
| `LMSTUDIO_BASE_URL` | `http://127.0.0.1:1234/v1` | Local LM Studio API |
| `LMSTUDIO_API_KEY` | `lm-studio` | Local LM Studio API key |
| `LMSTUDIO_TIMEOUT_SECONDS` | `120` | LM Studio request timeout |
| `LMSTUDIO_MAX_TOKENS` | `1024` | LM Studio output token limit |
| `LMSTUDIO_REASONING_EFFORT` | `none` | Disable extended reasoning for faster structured extraction |
| `FRESHSERVICE_CONNECT_TIMEOUT_SECONDS` | `5` | Freshservice connection timeout |
| `FRESHSERVICE_READ_TIMEOUT_SECONDS` | `30` | Freshservice read timeout |
| `INCIDENT_ANALYSIS_DEADLINE_SECONDS` | `120` | Shared analysis deadline |
| `MAX_RETRIES` | `2` | Maximum bounded retry count |
| `RETRY_BACKOFF_SECONDS` | `1` | Exponential retry backoff base |
| `MAX_CONVERSATION_PAGES` | `10` | Conversation pagination guard |
| `EXTRACTION_MAX_CHARS` | `50000` | Maximum cleaned text sent to the model |
| `MAX_ATTACHMENT_BYTES` | `10485760` | Maximum size of one downloaded attachment |
| `MAX_ATTACHMENTS` | `20` | Maximum attachments retrieved per ticket |
| `MAX_ATTACHMENT_PAGES` | `10` | Maximum pages rendered from one PDF |
| `MAX_ATTACHMENT_IMAGES` | `20` | Maximum image/PDF pages sent to the model |

Process environment values take precedence over `.env`. The
`config/entity_fields.json` file controls which entities the model must
extract for each business area. Add or change an area there instead of
changing Python code. Each area maps `business_area_values` to a `fields`
array; BI/MARS additionally maps `incident_categories` to `category_fields`,
so the model can select SCO EOD, Lighthouse Sales, or Rewards after the
Freshservice group identifies BI/MARS. Fields use `source: "model"` for
model-extracted values or a source such as `retail_details.store_number` for
deterministic values. Areas can set `exclude_common_fields` when a global field
does not apply. Add `freshservice_group_ids` when a Freshservice
assignment group must take precedence over ticket text and model
classification. No `incident_rules.json` file is required.

## Test commands

Run all synthetic tests without production credentials:

```powershell
py -m pytest -q
```

Run the deterministic domain tests:

```powershell
py -m pytest tests/test_rules.py -q
```

The suite covers complete and incomplete SCO EOD incidents, cross-domain
classification for Merchandising, TAM, Warehouse, BI Reports, and Loyalty,
manager-email inference and conflicts, missing and conflicting dates,
leading-zero SKUs, unrelated numbers, multiple stores/SKUs, chronological
conversation flow, screenshot/PDF preparation, multimodal request encoding,
malformed model output, Freshservice failures, deadlines, authoritative IDs,
malicious ticket instructions, optional fields, and the JSON CLI.

## Project layout

```text
analyze_incident.py         Direct JSON CLI entry point
model_status.py             Local model health check
bi_mars/config.py           Environment and rules loading
bi_mars/freshservice.py     Read-only Freshservice client
bi_mars/model_client.py     Shared model contract and response parsing
bi_mars/lmstudio.py         Local LM Studio provider
bi_mars/attachments.py      Image/PDF attachment preparation
bi_mars/pipeline.py         Deadline-bounded orchestration
bi_mars/rules.py            Deterministic safety and readiness logic
bi_mars/models.py           Pydantic contract models
bi_mars/text.py             HTML cleanup and JSON parsing
config/entity_fields.json   Business-area entity definitions
tests/                      Synthetic automated tests
```

The production ZIP intentionally excludes `tests/`, Python caches, the local
`.env`, model weights, logs, and downloaded attachments. Keep the source tests
outside the deployment directory if they are needed for maintenance.

## Troubleshooting

### Freshservice authentication or access failure

Confirm the URL has no `/api/v2` suffix, the API key is active, and the
credential has ticket and conversation view permissions. Freshservice uses the
API key as the username and `X` as the password for Basic authentication.

### Freshservice rate limiting

The client honors `Retry-After` for HTTP 429 and stops after the configured
retry count or shared deadline.

### LM Studio is unavailable or the model is missing

Run `py .\model_status.py` and
`Invoke-RestMethod http://127.0.0.1:1234/v1/models`. Start LM Studio, load
`LMSTUDIO_MODEL`, and confirm that its model ID appears in the response. The
application never falls back to another provider or silently changes models.

### Screenshots or PDFs are not analyzed

Confirm `PyMuPDF` is installed and that the loaded LM Studio model reports
vision support. The service renders PDFs to PNG pages before sending them; it
does not send Freshservice attachment URLs to any remote inference endpoint.

### Extraction output is invalid

The client includes the required schema in the model prompt, validates the
generated response with Pydantic, and makes one stricter retry. Repeated
malformed output is reported as `MODEL_INVALID_RESPONSE`.

### Analysis timed out

The response identifies the failed stage and returns
`ANALYSIS_DEADLINE_EXCEEDED`. Increase
`INCIDENT_ANALYSIS_DEADLINE_SECONDS` only when necessary, while keeping
individual connection and read timeouts bounded.

### Production release checklist

1. Create a clean virtual environment and install `requirements.txt`.
2. Copy `.env.example` to `.env` and set the Freshservice URL and server-side
   API key.
3. Run `py .\model_status.py` and verify the local LM Studio model.
4. Run `py -m pytest -q` in the source checkout before release.
5. Run `py .\analyze_incident.py INC-123456` and confirm the JSON and exit code.
6. Keep `.env`, model caches, logs, tests, attachments, and Python caches out
   of the deployment ZIP.

## Maintenance guide

### Add or change a business rule

1. Update `config/entity_fields.json` for a business area or entity field.
2. Update deterministic logic in `bi_mars/rules.py` only when new safety
   patterns or validation behavior are required.
3. Add synthetic tests for the positive case, a near-miss, and conflict
   behavior.
4. Run the focused tests and then the full suite.

### Change a Freshservice field or endpoint

1. Confirm the endpoint and response shape in the official Freshservice API
   documentation before coding.
2. Keep API calls in `bi_mars/freshservice.py`.
3. Preserve ticket IDs and API metadata separately from model inference.
4. Add fake-response integration tests. Never use production credentials in
   tests.
5. Check rate-limit cost, pagination, and permissions.

### Change the LM Studio model

1. Set `MODEL_NAME` and `LMSTUDIO_MODEL` to the loaded LM Studio model ID.
2. Verify the selected model supports the configured multimodal task.
3. Preserve schema validation and the strict retry.
4. Add a fixture for the model's actual response shape.

### Operate safely

- Review logs for latency, status, retry count, and validation failures only.
- Do not add full ticket descriptions or API headers to logs.
- Keep `.env` out of source control.
- Keep the service read-only unless a separately approved write workflow adds
  preview, explicit confirmation, authorization, and outcome recording.
