"""Check the configured local model provider."""

from __future__ import annotations

import json

from bi_mars.config import load_settings
from bi_mars.model_client import create_model_client


def main() -> int:
    settings = load_settings()
    client = create_model_client(settings)
    health = client.health()
    print(
        json.dumps(
            {
                "provider": health.provider,
                "model": health.configured_model,
                "reachable": health.reachable,
                "model_available": health.model_available,
                "message": health.message,
            },
            indent=2,
        )
    )
    return 0 if health.model_available else 1


if __name__ == "__main__":
    raise SystemExit(main())
