"""Run one Freshservice incident analysis and print JSON to stdout."""

from __future__ import annotations

import argparse
import json
import logging
import re
import sys
from typing import Optional, Sequence

from bi_mars.config import configured_entity_fields, load_entity_config, load_settings
from bi_mars.freshservice import FreshserviceClient
from bi_mars.logging_utils import configure_logging
from bi_mars.model_client import create_model_client
from bi_mars.pipeline import IncidentAnalysisService


LOGGER = logging.getLogger(__name__)


def _public_value(value: object) -> object:
    """Represent missing or empty values as JSON null."""
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    if isinstance(value, (list, tuple, set, dict)) and not value:
        return None
    return value


def _has_incident_value(value: object) -> bool:
    """Return whether a value was actually found in the incident evidence."""
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return True


def _field_value(
    field: dict[str, object],
    sources: dict[str, dict[str, object]],
    model_values: dict[str, object],
) -> object:
    name = str(field["name"])
    source = field.get("source")
    if source == "model":
        value = model_values.get(name)
    elif not isinstance(source, str) or "." not in source:
        return None
    else:
        section, key = source.split(".", 1)
        value = sources.get(section, {}).get(key)
        if value is None:
            value = model_values.get(name)
    pattern = field.get("pattern")
    if value is not None and isinstance(pattern, str) and not re.fullmatch(pattern, str(value).strip()):
        return None
    if value is not None and field.get("value_type") == "string":
        return str(value).strip()
    return value


def _normalise_entity_name(value: object) -> str:
    if not isinstance(value, str):
        return ""
    return re.sub(r"[^a-z0-9]+", "_", value.casefold()).strip("_")


def _incident_only(
    result: dict[str, object],
    requested_reference: str,
    *,
    entity_config: Optional[dict[str, object]] = None,
    freshservice_group_id: Optional[object] = None,
) -> dict[str, object]:
    """Return configured incident details as direct one-field objects."""
    payload = result.get("assessment")
    if not isinstance(payload, dict):
        failure = {
            "incident_number": requested_reference,
            "entities": [],
        }
        for key in ("error_code", "failed_stage", "message", "partial_results_available"):
            if key in result:
                failure[key] = result[key]
        return failure

    incident = payload.get("incident")
    classification = payload.get("classification")
    retail_details = payload.get("retail_details")
    model_entities = payload.get("entities")
    incident = incident if isinstance(incident, dict) else {}
    classification = classification if isinstance(classification, dict) else {}
    retail_details = retail_details if isinstance(retail_details, dict) else {}
    model_entities = model_entities if isinstance(model_entities, list) else []

    sources = {
        "incident": incident,
        "classification": classification,
        "retail_details": retail_details,
    }
    business_area = classification.get("business_area")
    incident_category = classification.get("issue_category")
    fields = configured_entity_fields(
        entity_config if entity_config is not None else load_entity_config(),
        business_area if isinstance(business_area, str) else None,
        freshservice_group_id=freshservice_group_id,
        incident_category=incident_category if isinstance(incident_category, str) else None,
    )

    model_values: dict[str, object] = {}
    entity_aliases: dict[str, str] = {}
    for field in fields:
        field_name = field.get("name")
        if not isinstance(field_name, str) or not field_name.strip():
            continue
        canonical = field_name.strip()
        entity_aliases[_normalise_entity_name(canonical)] = canonical
        aliases = field.get("aliases")
        if isinstance(aliases, list):
            for alias in aliases:
                normalized_alias = _normalise_entity_name(alias)
                if normalized_alias:
                    entity_aliases[normalized_alias] = canonical
    for item in model_entities:
        if not isinstance(item, dict):
            continue
        name = item.get("entity")
        if isinstance(name, str) and name.strip():
            canonical = entity_aliases.get(
                _normalise_entity_name(name),
                name.strip(),
            )
            model_values[canonical] = item.get("value")

    entities: list[dict[str, object]] = []
    known_entities = set()
    for field in fields:
        name = field["name"]
        if not isinstance(name, str) or not name.strip():
            continue
        name = name.strip()
        if name in known_entities:
            continue
        value = _public_value(
            _field_value(
                {**field, "name": name},
                sources,
                model_values,
            )
        )
        entities.append({name: value})
        known_entities.add(name)

    output = {
        "incident_number": requested_reference,
        "entities": entities,
    }
    if result.get("success") is False:
        for key in ("error_code", "failed_stage", "message", "partial_results_available"):
            if key in result:
                output[key] = result[key]
    return output


def _error_result(code: str, stage: str, message: str) -> dict[str, object]:
    return {
        "success": False,
        "error_code": code,
        "failed_stage": stage,
        "partial_results_available": False,
        "message": message,
    }


def analyze_incident(ticket_reference: str) -> dict[str, object]:
    """Analyze one ticket using the configured read-only backend clients."""
    settings = load_settings()
    configure_logging(settings.freshservice_api_key)
    freshservice = FreshserviceClient(settings)
    model_client = create_model_client(settings)
    service = IncidentAnalysisService(settings, freshservice, model_client)
    return service.analyze(ticket_reference).as_dict()


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Analyze one Freshservice incident and print structured JSON."
    )
    parser.add_argument(
        "incident_number",
        nargs="?",
        help="Freshservice incident number, for example INC-976902",
    )
    args = parser.parse_args(argv)

    if not args.incident_number or not args.incident_number.strip():
        result = _error_result(
            "INVALID_TICKET_REFERENCE",
            "input_validation",
            "Provide a Freshservice incident number, for example INC-976902.",
        )
        exit_code = 2
    else:
        try:
            analysis_result = analyze_incident(args.incident_number)
            result = _incident_only(
                analysis_result,
                args.incident_number.strip(),
                entity_config=load_entity_config(),
                freshservice_group_id=(
                    analysis_result.get("metrics", {}).get("freshservice_group_id")
                    if isinstance(analysis_result.get("metrics"), dict)
                    else None
                ),
            )
            exit_code = 0 if analysis_result.get("success") else 1
        except Exception as exc:  # pragma: no cover - final process safety net
            LOGGER.error("CLI analysis failed error_type=%s", type(exc).__name__)
            result = {
                "incident_number": args.incident_number.strip(),
                "entities": [],
            }
            exit_code = 1

    sys.stdout.write(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    sys.stdout.write("\n")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
