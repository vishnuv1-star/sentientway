"""Typed models for the extraction contract and assessment output."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


class ContractModel(BaseModel):
    model_config = ConfigDict(extra="ignore")


class IncidentMetadata(ContractModel):
    ticket_id: Optional[str] = None
    display_id: Optional[str] = None
    subject: str = ""
    requester_name: Optional[str] = None
    requester_email: Optional[str] = None
    status: Optional[str] = None
    priority: Optional[str] = None


class Classification(ContractModel):
    domain: str = "BI/MARS"
    business_area: str = "Unknown"
    incident_type: Optional[str] = None
    issue_category: Optional[str] = None
    request_type: Optional[str] = None
    affected_system: Optional[str] = None
    user_intent: str = ""
    summary: str = ""
    requested_action: str = ""
    expected_outcome: str = ""


class RetailDetails(ContractModel):
    store_number: Optional[str] = None
    kiosk_number: Optional[str] = None
    store_email: Optional[str] = None
    sco_eod_related: bool = False
    report_name: Optional[str] = None
    report_business_date: Optional[str] = None
    sku_ids: list[str] = Field(default_factory=list)
    affected_stores: list[str] = Field(default_factory=list)
    missing_item: Optional[str] = None
    error_message: Optional[str] = None
    additional_identifiers: list[str] = Field(default_factory=list)


class EvidenceEntry(ContractModel):
    field_name: str
    extracted_value: Any = None
    source_location: str = ""
    source: str = ""
    supporting_text: str = ""


class EntityValue(ContractModel):
    entity: str
    value: Any = None


class ValidationSummary(ContractModel):
    missing_required_fields: list[str] = Field(default_factory=list)
    invalid_fields: list[str] = Field(default_factory=list)
    ambiguous_fields: list[str] = Field(default_factory=list)
    conflicting_fields: list[str] = Field(default_factory=list)
    optional_missing_fields: list[str] = Field(default_factory=list)


class Clarification(ContractModel):
    required: bool = False
    questions: list[str] = Field(default_factory=list)
    message: str = ""
    reason: str = ""


AssessmentStatus = Literal[
    "NEEDS_CLARIFICATION",
    "INVALID_DATA",
    "CONFLICTING_INFORMATION",
    "READY_FOR_INVESTIGATION",
    "ANALYSIS_FAILED",
    "ANALYSIS_TIMED_OUT",
]


class Assessment(ContractModel):
    intake_status: AssessmentStatus = "NEEDS_CLARIFICATION"
    ready_for_investigation: bool = False
    next_steps: list[str] = Field(default_factory=list)


class ModelMetadata(ContractModel):
    model_name: str = "nuextract3"
    schema_version: str = "1.0"


class ExtractionPayload(ContractModel):
    incident: IncidentMetadata = Field(default_factory=IncidentMetadata)
    classification: Classification = Field(default_factory=Classification)
    retail_details: RetailDetails = Field(default_factory=RetailDetails)
    entities: list[EntityValue] = Field(default_factory=list)
    evidence: list[EvidenceEntry] = Field(default_factory=list)
    validation: ValidationSummary = Field(default_factory=ValidationSummary)
    clarification: Clarification = Field(default_factory=Clarification)
    assessment: Assessment = Field(default_factory=Assessment)
    model_metadata: ModelMetadata = Field(default_factory=ModelMetadata)


@dataclass
class TicketContext:
    """Freshservice data retained separately from model-inferred details."""

    ticket: dict[str, Any]
    conversations: list[dict[str, Any]] = field(default_factory=list)
    conversations_complete: bool = True
    conversation_error: Optional[str] = None
    attachments: list["AttachmentDocument"] = field(default_factory=list)
    attachment_error: Optional[str] = None


@dataclass
class AttachmentDocument:
    """A bounded Freshservice attachment kept in memory for multimodal extraction."""

    filename: str
    content_type: str
    source_location: str
    data: bytes = field(repr=False)


@dataclass
class AnalysisError:
    error_code: str
    failed_stage: str
    message: str
    partial_results_available: bool = False

    def as_dict(self) -> dict[str, Any]:
        return {
            "success": False,
            "error_code": self.error_code,
            "failed_stage": self.failed_stage,
            "partial_results_available": self.partial_results_available,
            "message": self.message,
        }


@dataclass
class AnalysisResponse:
    success: bool
    context: Optional[TicketContext] = None
    payload: Optional[ExtractionPayload] = None
    error: Optional[AnalysisError] = None
    metrics: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"success": self.success}
        if self.payload is not None:
            result["assessment"] = self.payload.model_dump()
        if self.error is not None:
            result.update(self.error.as_dict())
        if self.metrics:
            result["metrics"] = self.metrics
        return result
