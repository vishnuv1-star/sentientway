"""Application configuration and safe local .env loading."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterable, Optional


PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _read_dotenv(path: Path) -> Dict[str, str]:
    """Read simple KEY=VALUE entries without changing process environment."""
    values: Dict[str, str] = {}
    if not path.is_file():
        return values

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        values[key] = value
    return values


def _value(file_values: Dict[str, str], *names: str, default: Optional[str] = None) -> Optional[str]:
    for name in names:
        process_value = os.getenv(name)
        if process_value is not None and process_value.strip() != "":
            return process_value.strip()
        file_value = file_values.get(name)
        if file_value is not None and file_value.strip() != "":
            return file_value.strip()
    return default


def _int_value(file_values: Dict[str, str], names: Iterable[str], default: int) -> int:
    raw = _value(file_values, *tuple(names))
    try:
        parsed = int(raw) if raw is not None else default
        return parsed if parsed >= 0 else default
    except (TypeError, ValueError):
        return default


def _float_value(file_values: Dict[str, str], names: Iterable[str], default: float) -> float:
    raw = _value(file_values, *tuple(names))
    try:
        parsed = float(raw) if raw is not None else default
        return parsed if parsed > 0 else default
    except (TypeError, ValueError):
        return default


def _normalise_url(value: str) -> str:
    value = value.strip()
    if value and not value.startswith(("http://", "https://")):
        value = f"http://{value}"
    return value.rstrip("/")


@dataclass(frozen=True)
class Settings:
    """Runtime settings. Secrets are deliberately excluded from public views."""

    project_root: Path
    freshservice_url: str
    freshservice_api_key: str
    freshservice_workspace_id: Optional[int]
    model_provider: str
    model_name: str
    lmstudio_model: str
    lmstudio_base_url: str
    lmstudio_api_key: str
    lmstudio_timeout_seconds: float
    lmstudio_max_tokens: int
    lmstudio_reasoning_effort: str
    freshservice_connect_timeout_seconds: float
    freshservice_read_timeout_seconds: float
    incident_analysis_deadline_seconds: float
    max_retries: int
    retry_backoff_seconds: float
    max_conversation_pages: int
    max_ticket_list_items: int
    extraction_max_chars: int
    max_attachment_bytes: int
    max_attachments: int
    max_attachment_pages: int
    max_attachment_images: int
    config_file_values: Dict[str, str] = field(repr=False, compare=False)

    def configuration_issues(self) -> list[str]:
        issues: list[str] = []
        if not self.freshservice_url:
            issues.append("FRESHSERVICE_URL is not configured.")
        if not self.freshservice_api_key:
            issues.append("FRESHSERVICE_API_KEY is not configured.")
        if self.model_provider != "lmstudio":
            issues.append("MODEL_PROVIDER must be 'lmstudio'.")
        if not self.lmstudio_model:
            issues.append("LMSTUDIO_MODEL is not configured.")
        if not self.lmstudio_base_url:
            issues.append("LMSTUDIO_BASE_URL is not configured.")
        return issues

    def public_summary(self) -> dict[str, object]:
        """Return values safe to show in the UI and logs."""
        return {
            "freshservice_configured": bool(self.freshservice_url and self.freshservice_api_key),
            "freshservice_workspace_configured": self.freshservice_workspace_id is not None,
            "model_provider": self.model_provider,
            "model_name": self.model_name,
            "lmstudio_model": self.lmstudio_model,
            "lmstudio_base_url": self.lmstudio_base_url,
            "lmstudio_reasoning_effort": self.lmstudio_reasoning_effort,
            "analysis_deadline_seconds": self.incident_analysis_deadline_seconds,
            "max_retries": self.max_retries,
        }


def load_settings(project_root: Optional[Path] = None) -> Settings:
    root = (project_root or PROJECT_ROOT).resolve()
    file_values = _read_dotenv(root / ".env")

    workspace_raw = _value(file_values, "FRESHSERVICE_WORKSPACE_ID")
    try:
        workspace_id = int(workspace_raw) if workspace_raw else None
    except ValueError:
        workspace_id = None

    model_provider = (
        _value(file_values, "MODEL_PROVIDER", default="lmstudio")
        or "lmstudio"
    ).strip().lower()
    model_name = _value(file_values, "MODEL_NAME", default="nuextract3") or "nuextract3"

    return Settings(
        project_root=root,
        freshservice_url=_normalise_url(_value(file_values, "FRESHSERVICE_URL", default="") or ""),
        freshservice_api_key=_value(file_values, "FRESHSERVICE_API_KEY", default="") or "",
        freshservice_workspace_id=workspace_id,
        model_provider=model_provider,
        model_name=model_name,
        lmstudio_model=_value(
            file_values,
            "LMSTUDIO_MODEL",
            "MODEL_NAME",
            default="nuextract3",
        )
        or "nuextract3",
        lmstudio_base_url=_value(
            file_values,
            "LMSTUDIO_BASE_URL",
            default="http://127.0.0.1:1234/v1",
        )
        or "http://127.0.0.1:1234/v1",
        lmstudio_api_key=_value(
            file_values,
            "LMSTUDIO_API_KEY",
            default="lm-studio",
        )
        or "lm-studio",
        lmstudio_timeout_seconds=_float_value(
            file_values, ("LMSTUDIO_TIMEOUT_SECONDS",), 120.0
        ),
        lmstudio_max_tokens=_int_value(
            file_values, ("LMSTUDIO_MAX_TOKENS",), 1024
        ),
        lmstudio_reasoning_effort=_value(
            file_values,
            "LMSTUDIO_REASONING_EFFORT",
            default="none",
        ),
        freshservice_connect_timeout_seconds=_float_value(
            file_values, ("FRESHSERVICE_CONNECT_TIMEOUT_SECONDS",), 5.0
        ),
        freshservice_read_timeout_seconds=_float_value(
            file_values, ("FRESHSERVICE_READ_TIMEOUT_SECONDS",), 30.0
        ),
        incident_analysis_deadline_seconds=_float_value(
            file_values, ("INCIDENT_ANALYSIS_DEADLINE_SECONDS",), 120.0
        ),
        max_retries=_int_value(file_values, ("MAX_RETRIES",), 2),
        retry_backoff_seconds=_float_value(file_values, ("RETRY_BACKOFF_SECONDS",), 1.0),
        max_conversation_pages=_int_value(file_values, ("MAX_CONVERSATION_PAGES",), 100),
        max_ticket_list_items=_int_value(file_values, ("MAX_TICKET_LIST_ITEMS",), 30),
        extraction_max_chars=_int_value(file_values, ("EXTRACTION_MAX_CHARS",), 50000),
        max_attachment_bytes=_int_value(
            file_values, ("MAX_ATTACHMENT_BYTES",), 10 * 1024 * 1024
        ),
        max_attachments=_int_value(file_values, ("MAX_ATTACHMENTS",), 20),
        max_attachment_pages=_int_value(file_values, ("MAX_ATTACHMENT_PAGES",), 10),
        max_attachment_images=_int_value(file_values, ("MAX_ATTACHMENT_IMAGES",), 20),
        config_file_values=file_values,
    )


def load_entity_config(project_root: Optional[Path] = None) -> dict:
    """Load the business-area entity definitions used by extraction and output."""
    root = (project_root or PROJECT_ROOT).resolve()
    entity_path = root / "config" / "entity_fields.json"
    if not entity_path.is_file():
        return {}
    try:
        value = json.loads(entity_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


def configured_entity_fields(
    config: dict,
    business_area: Optional[str],
    freshservice_group_id: Optional[object] = None,
    incident_category: Optional[str] = None,
) -> list[dict[str, object]]:
    """Return common, area, and category-specific field definitions."""
    fields: list[dict[str, object]] = []

    def add_fields(value: object, excluded_names: Optional[set[str]] = None) -> None:
        if not isinstance(value, list):
            return
        for item in value:
            if (
                isinstance(item, dict)
                and isinstance(item.get("name"), str)
                and item["name"] not in (excluded_names or set())
            ):
                fields.append(dict(item))

    def normalise_label(value: object) -> str:
        if not isinstance(value, str):
            return ""
        return " ".join(value.casefold().replace("_", " ").replace("-", " ").split())

    def add_category_fields(area: dict[str, object]) -> None:
        category_fields = area.get("category_fields")
        categories = area.get("incident_categories")
        if not isinstance(category_fields, dict) or not isinstance(categories, list):
            return
        requested = normalise_label(incident_category)
        if not requested:
            return
        for category in categories:
            if not isinstance(category, dict) or not isinstance(category.get("name"), str):
                continue
            values = [
                category["name"],
                *(category.get("aliases") or []),
                category.get("key", ""),
            ]
            if requested not in {normalise_label(value) for value in values}:
                continue
            key = category.get("key")
            if not isinstance(key, str) or not key.strip():
                key = normalise_label(category["name"]).replace(" ", "_").upper()
            add_fields(category_fields.get(key))
            return

    areas = config.get("areas")
    if isinstance(areas, dict):
        for area in areas.values():
            if not isinstance(area, dict):
                continue
            group_ids = area.get("freshservice_group_ids", [])
            if freshservice_group_id is not None and isinstance(group_ids, list):
                if str(freshservice_group_id) in {str(value) for value in group_ids}:
                    excluded_common = {
                        str(value)
                        for value in area.get("exclude_common_fields", [])
                        if isinstance(value, str)
                    }
                    add_fields(config.get("common_fields"), excluded_common)
                    add_fields(area.get("fields"), excluded_common)
                    add_category_fields(area)
                    return fields
            values = area.get("business_area_values", [])
            if business_area and isinstance(values, list) and business_area in values:
                excluded_common = {
                    str(value)
                    for value in area.get("exclude_common_fields", [])
                    if isinstance(value, str)
                }
                add_fields(config.get("common_fields"), excluded_common)
                add_fields(area.get("fields"), excluded_common)
                add_category_fields(area)
                return fields
    add_fields(config.get("common_fields"))
    add_fields(config.get("default_fields"))
    return fields
