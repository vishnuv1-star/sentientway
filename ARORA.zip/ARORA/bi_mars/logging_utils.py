"""Minimal structured logging setup with secret redaction."""

from __future__ import annotations

import logging
import re
from typing import Iterable


class SecretRedactionFilter(logging.Filter):
    def __init__(self, secrets: Iterable[str] = ()) -> None:
        super().__init__()
        self._secrets = tuple(secret for secret in secrets if secret)

    def filter(self, record: logging.LogRecord) -> bool:
        message = record.getMessage()
        for secret in self._secrets:
            message = message.replace(secret, "[REDACTED]")
        message = re.sub(r"(authorization\s*[:=]\s*)\S+", r"\1[REDACTED]", message, flags=re.IGNORECASE)
        record.msg = message
        record.args = ()
        return True


def configure_logging(api_key: str = "") -> None:
    logger = logging.getLogger()
    if getattr(logger, "_bi_mars_configured", False):
        return
    handler = logging.StreamHandler()
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s %(levelname)s %(name)s %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )
    handler.addFilter(SecretRedactionFilter([api_key]))
    logger.addHandler(handler)
    # The CLI's stdout is the incident JSON contract. Keep routine request and
    # completion diagnostics out of terminal output; failures remain visible.
    logger.setLevel(logging.WARNING)
    logger._bi_mars_configured = True  # type: ignore[attr-defined]
