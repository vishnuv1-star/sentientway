"""Read-only Freshservice API v2 client with bounded retries and caching."""

from __future__ import annotations

import logging
import mimetypes
import re
import time
from datetime import datetime
from typing import Any, Optional
from urllib.parse import urljoin, urlparse

import requests

from .config import Settings
from .models import AttachmentDocument, TicketContext
from .text import clean_html


LOGGER = logging.getLogger(__name__)


class FreshserviceError(RuntimeError):
    """Base class for expected Freshservice failures."""

    def __init__(self, message: str, *, status_code: Optional[int] = None, code: str = "FRESHSERVICE_ERROR"):
        super().__init__(message)
        self.status_code = status_code
        self.code = code


class FreshserviceDeadlineExceeded(FreshserviceError):
    def __init__(self, stage: str = "freshservice_request"):
        super().__init__(
            "The analysis deadline was reached while contacting Freshservice.",
            code="ANALYSIS_DEADLINE_EXCEEDED",
        )
        self.stage = stage


class FreshserviceConfigurationError(FreshserviceError):
    def __init__(self, message: str):
        super().__init__(message, code="FRESHSERVICE_NOT_CONFIGURED")


class FreshserviceHttpError(FreshserviceError):
    pass


class FreshserviceTransportError(FreshserviceError):
    def __init__(self, message: str):
        super().__init__(message, code="FRESHSERVICE_UNAVAILABLE")


class FreshserviceClient:
    """Small, read-only client for ticket retrieval and conversation history."""

    def __init__(self, settings: Settings, session: Optional[requests.Session] = None) -> None:
        self.settings = settings
        self.session = session or requests.Session()
        self.session.auth = (settings.freshservice_api_key, "X")
        self.session.headers.update(
            {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "User-Agent": "bi-mars-incident-intelligence/0.1",
            }
        )

    @property
    def configured(self) -> bool:
        return bool(self.settings.freshservice_url and self.settings.freshservice_api_key)

    def _require_configured(self) -> None:
        if not self.configured:
            raise FreshserviceConfigurationError(
                "Freshservice is not configured. Set FRESHSERVICE_URL and FRESHSERVICE_API_KEY."
            )

    def _url(self, path: str) -> str:
        return urljoin(f"{self.settings.freshservice_url}/", path.lstrip("/"))

    @staticmethod
    def _retry_after(response: requests.Response) -> float:
        value = (response.headers or {}).get("Retry-After", "")
        try:
            return max(0.0, float(value))
        except (TypeError, ValueError):
            return 1.0

    def _request(
        self,
        path: str,
        *,
        params: Optional[dict[str, Any]] = None,
        deadline: Optional[float] = None,
        stage: str = "freshservice_request",
    ) -> tuple[dict[str, Any], requests.Response]:
        self._require_configured()
        attempts = self.settings.max_retries + 1
        last_transport_error: Optional[Exception] = None

        for attempt in range(attempts):
            remaining = deadline - time.monotonic() if deadline is not None else None
            if remaining is not None and remaining <= 0:
                raise FreshserviceDeadlineExceeded(stage)

            connect_timeout = self.settings.freshservice_connect_timeout_seconds
            read_timeout = self.settings.freshservice_read_timeout_seconds
            if remaining is not None:
                connect_timeout = min(connect_timeout, max(0.1, remaining))
                read_timeout = min(read_timeout, max(0.1, remaining))

            try:
                response = self.session.get(
                    self._url(path),
                    params=params,
                    timeout=(connect_timeout, read_timeout),
                )
            except requests.Timeout as exc:
                last_transport_error = exc
                can_retry = attempt + 1 < attempts
                LOGGER.warning("Freshservice request timed out stage=%s retry=%s", stage, can_retry)
                if not can_retry:
                    raise FreshserviceTransportError(
                        f"Freshservice did not respond within the configured timeout ({stage})."
                    ) from exc
                self._sleep_before_retry(attempt, deadline)
                continue
            except requests.RequestException as exc:
                last_transport_error = exc
                can_retry = attempt + 1 < attempts
                LOGGER.warning("Freshservice transport failure stage=%s retry=%s", stage, can_retry)
                if not can_retry:
                    raise FreshserviceTransportError(
                        "Freshservice could not be reached. Check the URL, network, and credentials."
                    ) from exc
                self._sleep_before_retry(attempt, deadline)
                continue

            if response.status_code == 429 or response.status_code in {500, 502, 503, 504}:
                if attempt + 1 < attempts:
                    delay = self._retry_after(response) if response.status_code == 429 else None
                    self._sleep_before_retry(attempt, deadline, override=delay)
                    continue
                message = (
                    "Freshservice rate limit reached; retry after the service-provided delay."
                    if response.status_code == 429
                    else "Freshservice returned a temporary server error."
                )
                raise FreshserviceHttpError(
                    message,
                    status_code=response.status_code,
                    code="FRESHSERVICE_RATE_LIMITED"
                    if response.status_code == 429
                    else "FRESHSERVICE_SERVER_ERROR",
                )

            if response.status_code in {401, 403}:
                raise FreshserviceHttpError(
                    "Freshservice rejected the configured credentials or permissions.",
                    status_code=response.status_code,
                    code="FRESHSERVICE_AUTHENTICATION_FAILED"
                    if response.status_code == 401
                    else "FRESHSERVICE_ACCESS_DENIED",
                )
            if response.status_code == 404:
                raise FreshserviceHttpError(
                    "The requested Freshservice ticket or resource was not found.",
                    status_code=404,
                    code="FRESHSERVICE_NOT_FOUND",
                )
            if response.status_code >= 400:
                raise FreshserviceHttpError(
                    f"Freshservice returned an HTTP {response.status_code} error.",
                    status_code=response.status_code,
                    code="FRESHSERVICE_HTTP_ERROR",
                )

            try:
                data = response.json()
            except (ValueError, requests.exceptions.JSONDecodeError) as exc:
                raise FreshserviceHttpError(
                    "Freshservice returned an invalid JSON response.",
                    status_code=response.status_code,
                    code="FRESHSERVICE_INVALID_RESPONSE",
                ) from exc
            if not isinstance(data, dict):
                raise FreshserviceHttpError(
                    "Freshservice returned an unexpected response shape.",
                    status_code=response.status_code,
                    code="FRESHSERVICE_INVALID_RESPONSE",
                )
            return data, response

        raise FreshserviceTransportError("Freshservice request failed.") from last_transport_error

    def _sleep_before_retry(
        self,
        attempt: int,
        deadline: Optional[float],
        *,
        override: Optional[float] = None,
    ) -> None:
        delay = (
            max(0.0, override)
            if override is not None
            else self.settings.retry_backoff_seconds * (2**attempt)
        )
        if deadline is not None:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise FreshserviceDeadlineExceeded()
            delay = min(delay, max(0.0, remaining - 0.01))
        if delay > 0:
            time.sleep(delay)

    def check_connection(self, *, deadline: Optional[float] = None) -> dict[str, Any]:
        """Check credentials and permissions without returning ticket bodies."""
        data, _ = self._request(
            "/api/v2/tickets",
            params=self._workspace_params({"per_page": 1, "page": 1}),
            deadline=deadline,
            stage="freshservice_health_check",
        )
        tickets = data.get("tickets")
        return {"ok": isinstance(tickets, list), "ticket_count_in_response": len(tickets or [])}

    def _workspace_params(self, params: dict[str, Any]) -> dict[str, Any]:
        if self.settings.freshservice_workspace_id is not None:
            params["workspace_id"] = self.settings.freshservice_workspace_id
        return params

    @staticmethod
    def normalize_ticket_reference(ticket_reference: str) -> str:
        reference = str(ticket_reference).strip()
        reference = re.sub(r"^#\s*", "", reference, flags=re.IGNORECASE)
        reference = re.sub(
            r"^(?:INC(?:IDENT)?|SR|SERVICE\s+REQUEST)[-\s]*",
            "",
            reference,
            flags=re.IGNORECASE,
        )
        return reference

    def get_ticket(self, ticket_reference: str, *, deadline: Optional[float] = None) -> dict[str, Any]:
        reference = self.normalize_ticket_reference(ticket_reference)
        if not re.fullmatch(r"\d+", reference):
            raise FreshserviceHttpError(
                "Enter a numeric Freshservice ticket number, such as INC-976902 or SR-836061.",
                code="INVALID_TICKET_REFERENCE",
            )
        data, _ = self._request(
            f"/api/v2/tickets/{reference}",
            params={"include": "requester"},
            deadline=deadline,
            stage="freshservice_ticket",
        )
        ticket = data.get("ticket")
        if not isinstance(ticket, dict):
            raise FreshserviceHttpError(
                "Freshservice did not return a ticket object.",
                code="FRESHSERVICE_INVALID_RESPONSE",
            )
        return ticket

    def list_tickets(
        self,
        *,
        page: int = 1,
        search: str = "",
        deadline: Optional[float] = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "per_page": min(100, self.settings.max_ticket_list_items),
            "page": max(1, page),
            "order_type": "desc",
            "type": "Incident",
        }
        params = self._workspace_params(params)
        data, _ = self._request(
            "/api/v2/tickets",
            params=params,
            deadline=deadline,
            stage="freshservice_ticket_list",
        )
        tickets = data.get("tickets")
        if not isinstance(tickets, list):
            return []
        cleaned_search = search.strip().lower()
        if not cleaned_search:
            return [ticket for ticket in tickets if isinstance(ticket, dict)]
        return [
            ticket
            for ticket in tickets
            if isinstance(ticket, dict)
            and (
                cleaned_search in str(ticket.get("id", "")).lower()
                or cleaned_search in str(ticket.get("display_id", "")).lower()
                or cleaned_search in str(ticket.get("subject", "")).lower()
            )
        ]

    def get_conversations(
        self,
        ticket_id: str,
        *,
        deadline: Optional[float] = None,
    ) -> tuple[list[dict[str, Any]], bool]:
        conversations: list[dict[str, Any]] = []
        for page in range(1, self.settings.max_conversation_pages + 1):
            data, response = self._request(
                f"/api/v2/tickets/{ticket_id}/conversations",
                params={"page": page, "per_page": 100},
                deadline=deadline,
                stage="freshservice_conversations",
            )
            page_items = data.get("conversations")
            if not isinstance(page_items, list):
                return self._chronological_conversations(conversations), True
            conversations.extend(item for item in page_items if isinstance(item, dict))
            if len(page_items) == 0 or (
                len(page_items) < 100 and not self._has_next_page(response)
            ):
                conversations = self._chronological_conversations(conversations)
                return conversations, True
        conversations = self._chronological_conversations(conversations)
        return conversations, False

    @staticmethod
    def _has_next_page(response: requests.Response) -> bool:
        link = response.headers.get("Link") or response.headers.get("link") or ""
        return bool(re.search(r'rel="?next"?', link, flags=re.IGNORECASE))

    @staticmethod
    def _chronological_conversations(
        conversations: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Sort by creation time when every message has a parseable timestamp."""
        parsed: list[tuple[datetime, dict[str, Any]]] = []
        for conversation in conversations:
            raw_timestamp = conversation.get("created_at")
            if not isinstance(raw_timestamp, str) or not raw_timestamp.strip():
                return conversations
            try:
                timestamp = datetime.fromisoformat(raw_timestamp.strip().replace("Z", "+00:00"))
            except ValueError:
                return conversations
            parsed.append((timestamp, conversation))
        return [conversation for _, conversation in sorted(parsed, key=lambda item: item[0])]

    def _download_attachment(
        self,
        metadata: dict[str, Any],
        *,
        source_location: str,
        deadline: Optional[float] = None,
    ) -> AttachmentDocument:
        raw_url = metadata.get("attachment_url") or metadata.get("url")
        if not isinstance(raw_url, str) or not raw_url.strip():
            raise FreshserviceHttpError(
                "Freshservice returned an attachment without a download URL.",
                code="FRESHSERVICE_ATTACHMENT_INVALID",
            )
        target_url = urljoin(f"{self.settings.freshservice_url}/", raw_url)
        base_host = urlparse(self.settings.freshservice_url).netloc.lower()
        target_host = urlparse(target_url).netloc.lower()
        if not base_host or target_host != base_host:
            raise FreshserviceHttpError(
                "The Freshservice attachment host did not match the configured account.",
                code="FRESHSERVICE_ATTACHMENT_HOST_REJECTED",
            )
        remaining = deadline - time.monotonic() if deadline is not None else None
        if remaining is not None and remaining <= 0:
            raise FreshserviceDeadlineExceeded("freshservice_attachment")
        connect_timeout = self.settings.freshservice_connect_timeout_seconds
        read_timeout = self.settings.freshservice_read_timeout_seconds
        if remaining is not None:
            connect_timeout = min(connect_timeout, max(0.1, remaining))
            read_timeout = min(read_timeout, max(0.1, remaining))
        try:
            response = self.session.get(
                target_url,
                timeout=(connect_timeout, read_timeout),
            )
        except requests.Timeout as exc:
            raise FreshserviceTransportError(
                "Freshservice attachment download timed out."
            ) from exc
        except requests.RequestException as exc:
            raise FreshserviceTransportError(
                "Freshservice attachment could not be downloaded."
            ) from exc
        if response.status_code >= 400:
            raise FreshserviceHttpError(
                f"Freshservice attachment download returned HTTP {response.status_code}.",
                status_code=response.status_code,
                code="FRESHSERVICE_ATTACHMENT_UNAVAILABLE",
            )
        data_chunks: list[bytes] = []
        total_bytes = 0
        iterator = getattr(response, "iter_content", None)
        if callable(iterator):
            for chunk in iterator(chunk_size=64 * 1024):
                if not chunk:
                    continue
                if not isinstance(chunk, bytes):
                    raise FreshserviceHttpError(
                        "Freshservice returned an invalid attachment body.",
                        code="FRESHSERVICE_ATTACHMENT_INVALID",
                    )
                total_bytes += len(chunk)
                if total_bytes > self.settings.max_attachment_bytes:
                    close = getattr(response, "close", None)
                    if callable(close):
                        close()
                    raise FreshserviceHttpError(
                        f"Attachment exceeds the configured {self.settings.max_attachment_bytes}-byte limit.",
                        code="FRESHSERVICE_ATTACHMENT_TOO_LARGE",
                    )
                data_chunks.append(chunk)
            data = b"".join(data_chunks)
        else:
            data = getattr(response, "content", b"")
            if not isinstance(data, bytes):
                raise FreshserviceHttpError(
                    "Freshservice returned an invalid attachment body.",
                    code="FRESHSERVICE_ATTACHMENT_INVALID",
                )
            if len(data) > self.settings.max_attachment_bytes:
                raise FreshserviceHttpError(
                    f"Attachment exceeds the configured {self.settings.max_attachment_bytes}-byte limit.",
                    code="FRESHSERVICE_ATTACHMENT_TOO_LARGE",
                )
        content_type = str(
            metadata.get("content_type")
            or (response.headers or {}).get("Content-Type")
            or mimetypes.guess_type(str(metadata.get("name") or ""))[0]
            or "application/octet-stream"
        ).split(";", 1)[0].strip().lower()
        filename = str(metadata.get("name") or metadata.get("filename") or "attachment")
        return AttachmentDocument(
            filename=filename,
            content_type=content_type,
            source_location=source_location,
            data=data,
        )

    def get_attachments(
        self,
        ticket: dict[str, Any],
        conversations: list[dict[str, Any]],
        *,
        deadline: Optional[float] = None,
    ) -> tuple[list[AttachmentDocument], Optional[str]]:
        metadata_items: list[tuple[dict[str, Any], str]] = []
        for index, item in enumerate(ticket.get("attachments") or [], start=1):
            if isinstance(item, dict):
                metadata_items.append((item, f"ticket.attachment[{index}]"))
        for conversation_index, conversation in enumerate(conversations, start=1):
            for attachment_index, item in enumerate(
                conversation.get("attachments") or [], start=1
            ):
                if isinstance(item, dict):
                    metadata_items.append(
                        (
                            item,
                            f"conversation[{conversation_index}].attachment[{attachment_index}]",
                        )
                    )
        documents: list[AttachmentDocument] = []
        errors: list[str] = []
        seen: set[str] = set()
        for metadata, source_location in metadata_items[: self.settings.max_attachments]:
            identity = str(
                metadata.get("id")
                or metadata.get("attachment_url")
                or metadata.get("url")
                or source_location
            )
            if identity in seen:
                continue
            seen.add(identity)
            try:
                documents.append(
                    self._download_attachment(
                        metadata,
                        source_location=source_location,
                        deadline=deadline,
                    )
                )
            except FreshserviceError as exc:
                if exc.code == "ANALYSIS_DEADLINE_EXCEEDED":
                    raise
                errors.append(f"{source_location}: {exc}")
        if len(metadata_items) > self.settings.max_attachments:
            errors.append(
                f"Attachment count exceeded the configured {self.settings.max_attachments}-item limit."
            )
        return documents, "; ".join(errors) if errors else None

    def get_context(self, ticket_reference: str, *, deadline: Optional[float] = None) -> TicketContext:
        key = self.normalize_ticket_reference(ticket_reference)
        ticket = self.get_ticket(key, deadline=deadline)
        ticket_id = str(ticket.get("id") or ticket.get("display_id") or key)
        conversations: list[dict[str, Any]] = []
        conversation_error: Optional[str] = None
        complete = True
        try:
            conversations, complete = self.get_conversations(ticket_id, deadline=deadline)
        except FreshserviceError as exc:
            if exc.code == "ANALYSIS_DEADLINE_EXCEEDED":
                raise
            conversation_error = str(exc)
            complete = False
            LOGGER.warning("Conversation retrieval incomplete code=%s", exc.code)
        attachments, attachment_error = self.get_attachments(
            ticket,
            conversations,
            deadline=deadline,
        )

        context = TicketContext(
            ticket=ticket,
            conversations=conversations,
            conversations_complete=complete,
            conversation_error=conversation_error,
            attachments=attachments,
            attachment_error=attachment_error,
        )
        return context


def ticket_source_documents(context: TicketContext) -> list[dict[str, str]]:
    """Build labelled, cleaned source documents for extraction and evidence."""
    ticket = context.ticket
    requester = ticket.get("requester") if isinstance(ticket.get("requester"), dict) else {}
    description_original = ticket.get("description")
    description_text = ticket.get("description_text") or clean_html(description_original)
    subject = str(ticket.get("subject") or "")
    requester_email = requester.get("email") or ticket.get("email") or ""
    requester_name = requester.get("name") or ""

    documents = [
        {"source": "subject", "source_location": "ticket.subject", "text": subject},
        {
            "source": "description",
            "source_location": "ticket.description",
            "text": clean_html(description_text),
        },
        {
            "source": "requester_email",
            "source_location": "ticket.requester.email",
            "text": str(requester_email),
        },
        {
            "source": "requester_name",
            "source_location": "ticket.requester.name",
            "text": str(requester_name),
        },
    ]
    custom_fields = ticket.get("custom_fields")
    if isinstance(custom_fields, dict):
        for key, value in custom_fields.items():
            if value not in (None, ""):
                documents.append(
                    {
                        "source": "custom_field",
                        "source_location": f"ticket.custom_fields.{key}",
                        "text": f"{key}: {clean_html(value)}",
                    }
                )
    for index, conversation in enumerate(context.conversations, start=1):
        body = conversation.get("body_text") or clean_html(conversation.get("body"))
        if body:
            metadata = [
                f"Conversation message {index} (chronological order)",
                f"Created: {conversation.get('created_at') or 'unknown'}",
                f"From: {conversation.get('from_email') or conversation.get('user_id') or 'unknown'}",
            ]
            if conversation.get("to_emails"):
                metadata.append(f"To: {conversation['to_emails']}")
            if conversation.get("cc_emails"):
                metadata.append(f"Cc: {conversation['cc_emails']}")
            if conversation.get("private") is not None:
                metadata.append(f"Private note: {conversation['private']}")
            documents.append(
                {
                    "source": "conversation",
                    "source_location": f"conversation[{index}]",
                    "text": "\n".join(
                        [
                            *metadata,
                            "Message:",
                            clean_html(body),
                        ]
                    ),
                }
            )
    for attachment in context.attachments:
        documents.append(
            {
                "source": "attachment",
                "source_location": attachment.source_location,
                "text": (
                    f"Attachment: {attachment.filename}\n"
                    f"Content type: {attachment.content_type}\n"
                    "The attachment must be inspected as visual document evidence."
                ),
            }
        )
    return documents
