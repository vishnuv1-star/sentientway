"""Prepare Freshservice image and PDF attachments for multimodal extraction."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .models import AttachmentDocument


@dataclass
class ImageInput:
    filename: str
    source_location: str
    content_type: str
    data: bytes


def prepare_attachments(
    attachments: list[AttachmentDocument],
    *,
    max_pages: int,
    max_images: int,
) -> tuple[list[dict[str, str]], list[ImageInput], Optional[str]]:
    """Render PDFs and preserve supported images for a multimodal request."""
    documents: list[dict[str, str]] = []
    images: list[ImageInput] = []
    errors: list[str] = []

    for attachment in attachments:
        if len(images) >= max_images:
            errors.append(f"Attachment images limited to {max_images} items.")
            break
        content_type = attachment.content_type.lower()
        is_pdf = content_type == "application/pdf" or attachment.filename.lower().endswith(".pdf")
        if is_pdf:
            try:
                import fitz

                pdf = fitz.open(stream=attachment.data, filetype="pdf")
                page_count = min(len(pdf), max_pages)
                if len(pdf) > max_pages:
                    errors.append(
                        f"{attachment.source_location}: PDF limited to {max_pages} pages."
                    )
                for page_number in range(page_count):
                    if len(images) >= max_images:
                        break
                    page = pdf.load_page(page_number)
                    pixmap = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
                    images.append(
                        ImageInput(
                            filename=f"{attachment.filename}#page-{page_number + 1}",
                            source_location=(
                                f"{attachment.source_location}.page[{page_number + 1}]"
                            ),
                            content_type="image/png",
                            data=pixmap.tobytes("png"),
                        )
                    )
                    if len(images) >= max_images:
                        break
                pdf.close()
                if len(images) >= max_images:
                    errors.append(f"Attachment images limited to {max_images} items.")
                    break
            except Exception as exc:
                errors.append(
                    f"{attachment.source_location}: PDF could not be rendered ({type(exc).__name__})."
                )
            continue

        if content_type.startswith("image/"):
            images.append(
                ImageInput(
                    filename=attachment.filename,
                    source_location=attachment.source_location,
                    content_type=content_type,
                    data=attachment.data,
                )
            )
            if len(images) >= max_images:
                errors.append(f"Attachment images limited to {max_images} items.")
                break
            continue

        documents.append(
            {
                "source": "attachment",
                "source_location": attachment.source_location,
                "text": (
                    f"Attachment {attachment.filename} has unsupported content type "
                    f"{attachment.content_type}; no visual extraction was attempted."
                ),
            }
        )

    if not images and attachments and not documents and not errors:
        errors.append("No supported image or PDF attachment was available for extraction.")
    return documents, images, "; ".join(errors) if errors else None
