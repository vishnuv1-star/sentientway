"""Deterministic BI/MARS extraction, validation, and clarification rules."""

from __future__ import annotations

import re
from datetime import date, datetime
from pathlib import Path
from typing import Any, Iterable, Optional

from dateutil import parser as date_parser

from .config import configured_entity_fields, load_entity_config
from .models import (
    Assessment,
    Classification,
    Clarification,
    EvidenceEntry,
    EntityValue,
    ExtractionPayload,
    IncidentMetadata,
    RetailDetails,
    ValidationSummary,
)
from .text import sentence_containing


DEFAULT_STORE_EMAIL_PATTERN = r"\b(?:sm|store|manager)[._-]?(?P<store>\d{4})@michaels\.com\b"
EMAIL_PATTERN = re.compile(r"\b[A-Z0-9._%+-]+@(?:michaels\.com)\b", re.IGNORECASE)
DATE_PATTERN = re.compile(
    r"\b(?:"
    r"\d{4}[-/]\d{1,2}[-/]\d{1,2}"
    r"|"
    r"\d{1,2}[-/]\d{1,2}[-/]\d{2,4}"
    r"|"
    r"(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|"
    r"Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|"
    r"Dec(?:ember)?)\s+\d{1,2}(?:,\s*|\s+)\d{4}"
    r")\b",
    re.IGNORECASE,
)
STORE_LABEL_PATTERN = re.compile(
    r"\b(?:store|location|site)s?\s*(?:number|num|no\.?|#)?\s*[:#-]?\s*(\d{4})\b",
    re.IGNORECASE,
)
KIOSK_LABEL_PATTERN = re.compile(
    r"\b(?:kiosk|self[-\s]?checkout|SCO)\s*"
    r"(?:number|num|no\.?|#)?\s*[:#-]?\s*(\d{2,3})\b",
    re.IGNORECASE,
)
STORE_GROUP_PATTERN = re.compile(
    r"\b(?:stores?|locations?|sites?)\b[^\n.]{0,80}?"
    r"(?P<numbers>\d{4}(?:\s*(?:,|and|&)\s*\d{4})+)",
    re.IGNORECASE,
)
SKU_CONTEXT_PATTERN = re.compile(
    r"\b(?:sku|skus|sku\s+ids?|sku\s+numbers?|item\s+ids?|item\s+numbers?|"
    r"identifiers?)\b[^.\n:]{0,28}?(?:is|are|include|includes|:)?\s*"
    r"((?:\d{2})(?:\s*(?:,|/|and|&)\s*\d{2})*)",
    re.IGNORECASE,
)
WAVE_NUMBER_PATTERN = re.compile(
    r"\bwave(?:\s*(?:id|number|no\.?))?\s*(?:is\s*)?[:#=-]?\s*"
    r"([A-Za-z][A-Za-z0-9_-]*\d[A-Za-z0-9_-]*|\d{4,})\b",
    re.IGNORECASE,
)
WAREHOUSE_NUMBER_PATTERN = re.compile(
    r"\b(?:warehouse|WH)\s*(?:number|no\.?|id)?\s*(?:is\s*)?[:#=-]?\s*"
    r"(\d{2,3})(?!\d)\b",
    re.IGNORECASE,
)
LIST_ID_PATTERN = re.compile(
    r"\b(?:list\s*id|list\s*(?:number|no\.?)|pick\s*list\s*(?:id|number|no\.?)?)"
    r"\s*(?:is\s*)?[:#=-]?\s*([A-Za-z0-9][A-Za-z0-9_-]*)\b",
    re.IGNORECASE,
)
LIST_ID_TOKEN_PATTERN = re.compile(r"\bLST\d{12}\b", re.IGNORECASE)
DC_NAME_PATTERN = re.compile(
    r"\b(?:DC|distribution\s+center|distribution\s+centre|warehouse)\s+name"
    r"\s*(?:is\s*)?[:=-]\s*([A-Za-z][A-Za-z0-9 &'./()-]{1,80}?)(?=[,;\n.]|$)",
    re.IGNORECASE,
)
WMS_DC_NUMBER_PATTERN = re.compile(
    r"\b(?:store|location|site)\s*(?:number|num|no\.?|#)?\s*[:#-]\s*"
    r"(\d{6})\s*\|\s*DC\b",
    re.IGNORECASE,
)
DC_NUMBER_PATTERN = re.compile(
    r"\b(?:DC|distribution\s+center|distribution\s+centre)\s*"
    r"(?:number|num|no\.?|id)\s*(?:is\s*)?[:#=-]?\s*(\d{6})\b",
    re.IGNORECASE,
)
WMS_DC_TOKEN_PATTERN = re.compile(r"\bDC-[A-Za-z0-9][A-Za-z0-9_-]*\b", re.IGNORECASE)
WMS_WAVE_TOKEN_PATTERN = re.compile(
    r"\b(?:BAT|WAVE)[A-Z0-9_-]*\d[A-Z0-9_-]*\b",
    re.IGNORECASE,
)
WMS_PICK_TYPE_PATTERN = re.compile(r"\bRTC(?:\s+[A-Z0-9]+){1,2}\b", re.IGNORECASE)
WMS_PICK_STATUS_PATTERN = re.compile(
    r"\bpicks?\b[^\n.]{0,80}?\b(physically\s+picked)\b",
    re.IGNORECASE,
)
WMS_PTL_STATUS_PATTERN = re.compile(
    r"\b(?:picks?|items?)\s+need\s+to\s+be\s+confirmed\b",
    re.IGNORECASE,
)
LIST_ID_STOP_WORDS = {
    "display",
    "issue",
    "missing",
    "none",
    "not",
    "stuck",
    "unknown",
}

BUSINESS_AREA_PATTERNS: tuple[tuple[str, str], ...] = (
    (
        "RMS",
        r"\bRMS\b|\bretail\s+management\s+system\b",
    ),
    (
        "Merchandising",
        r"\bmerchandis(?:e|ing|ed)\b|\bassortment\b|\bplanogram\b|\bpricing\b|\bpromotion(?:s)?\b",
    ),
    (
        "TAM",
        r"\bTAM\b|\bterminal\s+asset\s+management\b|\basset\s+management\b",
    ),
    (
        "WMS",
        r"\bWMS\b|\bwarehouse\s+management\s+system\b",
    ),
    (
        "Warehouse",
        r"\bwarehouse\b|\bdistribution\s+center\b|\bdistribution\s+centre\b|\bDC\b|\bshipping\b|\bshipment\b",
    ),
    (
        "Loyalty",
        r"\bloyal(?:ty|ity)\b|\brewards?\b|\bmember(?:ship)?\b|\bpoints?\b|\bMichaels\s+Rewards\b",
    ),
    (
        "BI Reports",
        r"\bBI\b|\bMARS\b|\bbusiness\s+intelligence\b|\bdashboard\b|\bdata\s+warehouse\b|\bETL\b|"
        r"\breport(?:s|ing)?\b|\bdata\s+(?:load|pipeline|refresh|extract)\b",
    ),
    (
        "Store Operations",
        r"\bstore\b|\bSCO\b|\bself[-\s]?checkout\b|\bPOS\b|\bpoint\s+of\s+sale\b|"
        r"\btax\b|\bdeposit\b|\breceipt\b",
    ),
)


def _all_documents_text(documents: list[dict[str, str]]) -> str:
    return "\n".join(
        f"[{item.get('source_location', item.get('source', 'source'))}] {item.get('text', '')}"
        for item in documents
        if item.get("text")
    )


def _clean_scalar(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() in {"unknown", "n/a", "not found", "null", "none"}:
        return None
    return text


def _unique(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        if value and value not in result:
            result.append(value)
    return result


def _model_entity_value(
    entities: list[EntityValue],
    *labels: str,
) -> Any:
    wanted = {
        re.sub(r"[^a-z0-9]+", "_", label.casefold()).strip("_")
        for label in labels
    }
    value: Any = None
    for entity in entities:
        if not isinstance(entity.entity, str):
            continue
        normalized = re.sub(
            r"[^a-z0-9]+",
            "_",
            entity.entity.casefold(),
        ).strip("_")
        if normalized in wanted:
            value = entity.value
    return value


def _evidence(
    field_name: str,
    value: Any,
    document: dict[str, str],
    *,
    supporting_text: Optional[str] = None,
) -> EvidenceEntry:
    source_text = document.get("text", "")
    return EvidenceEntry(
        field_name=field_name,
        extracted_value=value,
        source_location=document.get("source_location", document.get("source", "")),
        source=document.get("source", ""),
        supporting_text=supporting_text or sentence_containing(source_text, str(value)),
    )


def _date_parse(raw: str) -> tuple[Optional[str], bool]:
    """Return ISO value and whether the date was ambiguous."""
    value = raw.strip()
    if value.casefold() == "yesterday":
        return "yesterday", False
    if re.fullmatch(r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}", value):
        pieces = re.split(r"[/-]", value)
        first, second = int(pieces[0]), int(pieces[1])
        if first <= 12 and second <= 12:
            return None, True
    formats = ("%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%m-%d-%Y", "%m/%d/%y", "%m-%d-%y")
    for fmt in formats:
        try:
            parsed = datetime.strptime(value, fmt).date()
            return parsed.isoformat(), False
        except ValueError:
            continue
    try:
        parsed = date_parser.parse(value, fuzzy=False, dayfirst=False).date()
    except (ValueError, OverflowError, TypeError):
        return None, False
    return parsed.isoformat(), False


def _date_candidates(documents: list[dict[str, str]]) -> tuple[list[tuple[str, dict[str, str], str]], list[tuple[str, dict[str, str], str]]]:
    reliable: list[tuple[str, dict[str, str], str]] = []
    ambiguous: list[tuple[str, dict[str, str], str]] = []
    for document in documents:
        text = document.get("text", "")
        for match in DATE_PATTERN.finditer(text):
            raw = match.group(0)
            window = text[max(0, match.start() - 90) : min(len(text), match.end() + 90)]
            # Dates are business dates only when tied to the reporting issue. The
            # ticket creation date is never included in source documents.
            relevant = bool(
                re.search(
                    r"business\s+date|report(?:ing)?\s+date|date\s+of\s+(?:the\s+)?report|"
                    r"sco\s*[-_/]?\s*eod|self[-\s]?checkout|end[-\s]?of[-\s]?day|"
                    r"missing|delayed|affected",
                    window,
                    flags=re.IGNORECASE,
                )
            )
            if not relevant:
                continue
            normalized, is_ambiguous = _date_parse(raw)
            if is_ambiguous:
                ambiguous.append((raw, document, window))
            elif normalized:
                reliable.append((normalized, document, window))
        for match in re.finditer(r"\byesterday\b", text, flags=re.IGNORECASE):
            window = text[max(0, match.start() - 90) : min(len(text), match.end() + 90)]
            relevant = bool(
                re.search(
                    r"business\s+date|report(?:ing)?\s+date|sco\s*[-_/]?\s*eod|"
                    r"self[-\s]?checkout|end[-\s]?of[-\s]?day|missing|delayed|affected",
                    window,
                    flags=re.IGNORECASE,
                )
            )
            if relevant:
                reliable.append(("yesterday", document, window))
    return reliable, ambiguous


def _is_sco_eod(text: str) -> bool:
    sco = bool(re.search(r"\bSCO\b|self[-\s]?checkout", text, flags=re.IGNORECASE))
    eod = bool(re.search(r"\bEOD\b|end[-\s]?of[-\s]?day", text, flags=re.IGNORECASE))
    return sco and eod


def _is_missing_report(text: str) -> bool:
    return bool(
        re.search(
            r"(?:missing|missed|not\s+(?:received|available|showing)|did\s+not\s+receive|"
            r"cannot\s+find|can't\s+find|absent|delayed|late).{0,80}"
            r"(?:report|file|data|output)|(?:report|file|data|output).{0,80}"
            r"(?:missing|missed|not\s+(?:received|available|showing)|absent|delayed|late)",
            text,
            flags=re.IGNORECASE | re.DOTALL,
        )
    )


def _extract_emails(documents: list[dict[str, str]]) -> list[tuple[str, dict[str, str]]]:
    found: list[tuple[str, dict[str, str]]] = []
    for document in documents:
        for match in EMAIL_PATTERN.finditer(document.get("text", "")):
            found.append((match.group(0), document))
    return found


def _extract_store_candidates(
    documents: list[dict[str, str]],
    store_email_pattern: str,
) -> tuple[dict[str, list[EvidenceEntry]], list[EvidenceEntry], Optional[str]]:
    candidates: dict[str, list[EvidenceEntry]] = {}
    email_evidence: list[EvidenceEntry] = []
    email_candidate_keys: set[tuple[str, str, str]] = set()
    try:
        email_regex = re.compile(store_email_pattern, flags=re.IGNORECASE)
    except re.error:
        email_regex = re.compile(DEFAULT_STORE_EMAIL_PATTERN, flags=re.IGNORECASE)

    for document in documents:
        text = document.get("text", "")
        for match in STORE_LABEL_PATTERN.finditer(text):
            store = match.group(1)
            candidates.setdefault(store, []).append(
                _evidence("store_number", store, document, supporting_text=match.group(0))
            )
        for match in STORE_GROUP_PATTERN.finditer(text):
            context_text = match.group(0)
            for store in re.findall(r"(?<!\d)\d{4}(?!\d)", match.group("numbers")):
                candidates.setdefault(store, []).append(
                    _evidence("store_number", store, document, supporting_text=context_text)
                )
        for match in email_regex.finditer(text):
            store = match.groupdict().get("store")
            if not store:
                continue
            email_source_location = document.get("source_location", "")
            if re.search(r"(?:^|\n)\s*Cc\s*:", text, flags=re.IGNORECASE):
                email_source_location = f"{email_source_location}.cc"
            email_document = {
                **document,
                "source_location": email_source_location,
            }
            candidate_evidence = _evidence(
                "store_number",
                store,
                email_document,
                supporting_text=match.group(0),
            )
            candidates.setdefault(store, []).append(candidate_evidence)
            email_candidate_keys.add(
                (
                    store,
                    candidate_evidence.source_location,
                    candidate_evidence.supporting_text,
                )
            )
            email_evidence.append(
                _evidence("store_email", match.group(0), email_document, supporting_text=match.group(0))
            )

    explicit_candidates: dict[str, list[EvidenceEntry]] = {}
    for store, entries in candidates.items():
        explicit_entries = [
            entry
            for entry in entries
            if (
                store,
                entry.source_location,
                entry.supporting_text,
            ) not in email_candidate_keys
        ]
        if explicit_entries:
            explicit_candidates[store] = explicit_entries

    cc_email_evidence = [
        entry
        for entry in email_evidence
        if entry.source_location.lower().endswith(".cc")
    ]
    requester_email_evidence = [
        entry
        for entry in email_evidence
        if entry.source_location == "ticket.requester.email"
    ]
    preferred_email_evidence = (
        cc_email_evidence
        or requester_email_evidence
        or email_evidence
    )

    if explicit_candidates:
        selected_candidates = explicit_candidates
    else:
        selected_candidates = {}
        for entry in preferred_email_evidence:
            store = str(entry.extracted_value).split("@", 1)[0]
            match = re.search(r"(?P<store>\d{4})$", store)
            if match:
                selected_candidates.setdefault(match.group("store"), []).append(
                    _evidence(
                        "store_number",
                        match.group("store"),
                        {
                            "source": entry.source,
                            "source_location": entry.source_location,
                            "text": entry.supporting_text,
                        },
                        supporting_text=entry.supporting_text,
                    )
                )

    store_email = (
        preferred_email_evidence[0].extracted_value
        if preferred_email_evidence
        else None
    )
    return selected_candidates, email_evidence, str(store_email) if store_email else None


def _extract_kiosk_candidates(
    documents: list[dict[str, str]],
) -> tuple[list[str], list[tuple[str, dict[str, str], str]]]:
    """Extract explicitly labelled two- or three-digit kiosk identifiers."""
    candidates: list[str] = []
    evidence: list[tuple[str, dict[str, str], str]] = []
    for document in documents:
        text = document.get("text", "")
        for match in KIOSK_LABEL_PATTERN.finditer(text):
            kiosk = match.group(1)
            if kiosk not in candidates:
                candidates.append(kiosk)
            evidence.append((kiosk, document, match.group(0)))
    return candidates, evidence


def _extract_skus(documents: list[dict[str, str]]) -> list[tuple[str, dict[str, str], str]]:
    found: list[tuple[str, dict[str, str], str]] = []
    for document in documents:
        text = document.get("text", "")
        for match in SKU_CONTEXT_PATTERN.finditer(text):
            for value in re.findall(r"(?<!\d)\d{2}(?!\d)", match.group(1)):
                found.append((value, document, match.group(0)))
    return found


def _extract_wms_identifiers(
    documents: list[dict[str, str]],
) -> tuple[dict[str, str], list[EvidenceEntry]]:
    """Extract labeled WMS identifiers from all ticket and conversation text.

    Conversation documents are ordered chronologically, so later values replace
    earlier values when the ticket clarifies or corrects an identifier.
    """
    values: dict[str, str] = {}
    evidence: list[EvidenceEntry] = []
    patterns = (
        ("wave_number", WAVE_NUMBER_PATTERN),
        ("warehouse_number", WAREHOUSE_NUMBER_PATTERN),
        ("list_id", LIST_ID_PATTERN),
        ("dc_name", DC_NAME_PATTERN),
        ("dc_number", WMS_DC_NUMBER_PATTERN),
        ("dc_number", DC_NUMBER_PATTERN),
    )
    for document in documents:
        text = document.get("text", "")
        for field_name, pattern in patterns:
            for match in pattern.finditer(text):
                value = match.group(1).strip()
                if field_name == "list_id" and value.casefold() in LIST_ID_STOP_WORDS:
                    continue
                values[field_name] = value
                evidence.append(
                    _evidence(
                        field_name,
                        value,
                        document,
                        supporting_text=match.group(0),
                    )
                )
        for match in LIST_ID_TOKEN_PATTERN.finditer(text):
            value = match.group(0).upper()
            values["list_id"] = value
            evidence.append(
                _evidence(
                    "list_id",
                    value,
                    document,
                    supporting_text=match.group(0),
                )
            )
        for field_name, pattern in (
            ("dc_name", WMS_DC_TOKEN_PATTERN),
            ("wave_number", WMS_WAVE_TOKEN_PATTERN),
            ("pick_type", WMS_PICK_TYPE_PATTERN),
        ):
            for match in pattern.finditer(text):
                value = match.group(0).strip()
                values[field_name] = value
                evidence.append(
                    _evidence(
                        field_name,
                        value,
                        document,
                        supporting_text=match.group(0),
                    )
                )
        for match in WMS_PICK_STATUS_PATTERN.finditer(text):
            value = match.group(1).strip().lower()
            values["pick_status"] = value
            evidence.append(
                _evidence(
                    "pick_status",
                    value,
                    document,
                    supporting_text=match.group(0),
                )
            )
        for match in WMS_PTL_STATUS_PATTERN.finditer(text):
            value = "needs confirmation"
            values["ptl_confirmation_status"] = value
            evidence.append(
                _evidence(
                    "ptl_confirmation_status",
                    value,
                    document,
                    supporting_text=match.group(0),
                )
            )
    return values, evidence


def _infer_report_name(text: str, sco_eod_related: bool) -> Optional[str]:
    if sco_eod_related:
        return "SCO EOD report"
    request_words = {
        "can",
        "could",
        "please",
        "share",
        "send",
        "provide",
        "screenshot",
        "screen",
        "show",
        "the",
        "a",
        "an",
        "of",
        "this",
        "that",
    }

    # Prefer an explicit field-style name, for example "Report Name: Daily Sales".
    labeled = re.search(
        r"\b(?:report\s+(?:name|type)|dashboard\s+name)\s*[:=-]\s*([^\n.;]{2,100})",
        text,
        flags=re.IGNORECASE,
    )
    if labeled:
        candidate = re.sub(r"\s+", " ", labeled.group(1)).strip(" -:")
        words = candidate.lower().split()
        if candidate and not any(word in request_words for word in words):
            return candidate

    # Only infer a name from a short phrase immediately before "report".
    # This deliberately rejects request language such as
    # "share the screenshot of the report".
    for match in re.finditer(
        r"\b((?:[A-Za-z0-9/&-]+\s+){1,5})report\b",
        text,
        flags=re.IGNORECASE,
    ):
        candidate = re.sub(r"\s+", " ", f"{match.group(1)}report").strip(" -:")
        words = candidate.lower().split()
        if (
            len(words) >= 2
            and words[-1] == "report"
            and not any(word in request_words for word in words[:-1])
        ):
            return candidate
    return None


def _infer_missing_item(text: str) -> Optional[str]:
    lowered = text.lower()
    if "incomplete data" in lowered or "partial data" in lowered:
        return "incomplete_data"
    if "delayed report" in lowered or "report is late" in lowered or "report was late" in lowered:
        return "delayed_report"
    if re.search(r"\bmissing\s+(?:source\s+)?file\b|\bfile\s+is\s+missing\b", lowered):
        return "missing_file"
    if re.search(
        r"\bmissing\s+(?:report|output)\b|"
        r"\b(?:report|file|data|output)(?:\s+output)?\s+is\s+missing\b|"
        r"\bno\s+report\b",
        lowered,
    ):
        return "missing_report_output"
    if re.search(r"\bmissing\s+data\b|\bdata\s+is\s+missing\b", lowered):
        return "missing_data"
    return None


def _infer_business_area(
    text: str,
    entity_config: Optional[dict[str, Any]] = None,
    freshservice_group_id: Optional[object] = None,
) -> str:
    configured = entity_config if entity_config is not None else load_entity_config()
    areas = configured.get("areas") if isinstance(configured, dict) else None
    if isinstance(areas, dict):
        # An explicit Freshservice group is authoritative over ticket wording.
        for area in areas.values():
            if not isinstance(area, dict):
                continue
            group_ids = area.get("freshservice_group_ids", [])
            if freshservice_group_id is not None and isinstance(group_ids, list):
                if str(freshservice_group_id) in {str(value) for value in group_ids}:
                    values = area.get("business_area_values", [])
                    if values and isinstance(values[0], str):
                        return values[0]

        # Specific configured Store Operations categories must win over broad
        # BI/report wording that can appear in the same incident description.
        if _store_operations_category(text, None) is not None:
            return "Store Operations"

        # Only after the specific category check should broad configured area
        # labels such as "BI Reports" influence routing.
        for area in areas.values():
            if not isinstance(area, dict):
                continue
            values = area.get("business_area_values")
            if not isinstance(values, list):
                continue
            for value in values:
                if not isinstance(value, str) or not value.strip():
                    continue
                if re.search(
                    rf"(?<!\w){re.escape(value.strip())}(?!\w)",
                    text,
                    flags=re.IGNORECASE,
                ):
                    canonical = values[0] if isinstance(values[0], str) else value
                    return canonical
    for area, pattern in BUSINESS_AREA_PATTERNS:
        if re.search(pattern, text, flags=re.IGNORECASE):
            return area
    return "Unknown"


def _infer_request_type(text: str) -> Optional[str]:
    if re.search(
        r"\b(?:cannot|can't|unable|failed|failure|broken|error|issue|problem|missing|"
        r"incident|offline|not\s+(?:working|available|received|showing)|delayed)\b",
        text,
        flags=re.IGNORECASE,
    ):
        return "incident"
    if re.search(r"\b(?:access|permission|authorize|login|password|role)\b", text, re.IGNORECASE):
        return "access_request"
    if re.search(r"\b(?:change|update|modify|add|remove|configure)\b", text, re.IGNORECASE):
        return "change_request"
    if re.search(r"\b(?:how|where|when|what is|can you explain)\b", text, re.IGNORECASE):
        return "information_request"
    if re.search(r"\b(?:provide|send|share|need|get)\b", text, re.IGNORECASE):
        return "data_request"
    return None


def _category_for_business_area(business_area: str) -> Optional[str]:
    return {
        "Merchandising": "RMS_GENERAL_ISSUE",
        "TAM": "TAM_GENERAL_ISSUE",
        "RMS": "RMS_GENERAL_ISSUE",
        "Loyalty": "LOYALTY_ACCOUNT_ISSUE",
    }.get(business_area)


def _configured_area_category(
    text: str,
    model_issue_category: Optional[str],
    business_area: str,
    entity_config: dict[str, Any],
) -> Optional[str]:
    """Resolve a configured category from source evidence, then model output.

    Explicit category wording in the ticket must take precedence over a model
    category because the selected category controls the entity allowlist. This
    prevents a model misclassification from exposing fields from a different
    WMS workflow, such as list identifiers on a load-stop incident.
    """
    areas = entity_config.get("areas") if isinstance(entity_config, dict) else None
    if not isinstance(areas, dict):
        return None
    normalized_model = re.sub(
        r"[^a-z0-9]+",
        " ",
        (_clean_scalar(model_issue_category) or "").casefold(),
    ).strip()
    for area in areas.values():
        if not isinstance(area, dict):
            continue
        values = area.get("business_area_values")
        if not isinstance(values, list) or not any(
            isinstance(value, str) and value.casefold() == business_area.casefold()
            for value in values
        ):
            continue
        categories = area.get("incident_categories")
        if not isinstance(categories, list):
            return None

        # Ticket and conversation text are the source evidence. Check all
        # configured labels before trusting the model's classification.
        for category in categories:
            if not isinstance(category, dict):
                continue
            key = category.get("key")
            name = category.get("name")
            canonical = key if isinstance(key, str) and key.strip() else name
            if not isinstance(canonical, str) or not canonical.strip():
                continue
            labels = [name, key, *(category.get("aliases") or [])]
            for label in labels:
                if isinstance(label, str) and label.strip() and re.search(
                    rf"(?<!\w){re.escape(label)}(?!\w)",
                    text,
                    flags=re.IGNORECASE,
                ):
                    return canonical

        # Fall back to the model only when the source text does not identify
        # a configured category.
        for category in categories:
            if not isinstance(category, dict):
                continue
            key = category.get("key")
            name = category.get("name")
            canonical = key if isinstance(key, str) and key.strip() else name
            if not isinstance(canonical, str) or not canonical.strip():
                continue
            labels = [name, key, *(category.get("aliases") or [])]
            normalized_labels = {
                re.sub(r"[^a-z0-9]+", " ", str(label).casefold()).strip()
                for label in labels
                if isinstance(label, str) and label.strip()
            }
            if normalized_model and normalized_model in normalized_labels:
                return canonical


def _bi_mars_category(
    text: str,
    model_issue_category: Optional[str],
) -> Optional[str]:
    """Identify the configured BI/MARS subcategory without inventing values."""
    model_category = _clean_scalar(model_issue_category)
    normalized_model = model_category.casefold().replace("_", " ") if model_category else ""
    if normalized_model in {"sco eod", "sco eod missing report"}:
        return "SCO_EOD"
    if normalized_model in {
        "pricing promotion issue",
        "pricing / promotion / pog",
        "pricing promotion pog",
    }:
        return "Pricing / Promotion / POG"
    if normalized_model in {"lighthouse sales", "lighthouse"}:
        return "Lighthouse Sales"
    if normalized_model in {
        "jda sales mismatch",
        "jda sales discrepancy",
        "sales units mismatch",
        "jda not reflecting sales",
        "power bi sales mismatch",
        "sales data discrepancy",
    }:
        return "JDA_SALES_MISMATCH"
    if normalized_model in {"rewards", "rewards incident"}:
        return "Rewards"
    if _is_sco_eod(text):
        return "SCO_EOD"
    if re.search(
        r"\bkiosk\b|\bself[-\s]?checkout(?:s)?\b|\bcash\s+sales\b",
        text,
        flags=re.IGNORECASE,
    ):
        return "SCO EOD"
    if re.search(
        r"\bpricing\s+(?:issue|problem)\b|"
        r"\bpromotion\s+(?:issue|problem)\b|"
        r"\b(?:sale\s+price|price)\s+(?:is\s+)?(?:incorrect|wrong|not\s+(?:ringing|scanning))\b|"
        r"\bPOG\s+issue\b|\bincorrect\s+discount\b|\bcustom\s+framing\s+pricing\b",
        text,
        flags=re.IGNORECASE,
    ):
        return "Pricing / Promotion / POG"
    if re.search(
        r"\blighthouse\b|\bcustom\s+framing\b|\b(?:cf|custom\s+framing)\s+ontime\b|"
        r"\bservice\s+sales\b|\btotal\s+sales\b",
        text,
        flags=re.IGNORECASE,
    ):
        return "Lighthouse Sales"
    if re.search(
        r"\bJDA\b.{0,80}\b(?:sales|units|mismatch|discrepancy)\b|"
        r"\bsales\s+units?\s+(?:mismatch|discrepancy)\b|"
        r"\bPower\s+BI\b.{0,80}\bsales\s+(?:mismatch|discrepancy)\b|"
        r"\bVendor\s+Connect\b.{0,80}\bsales\b",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        return "JDA_SALES_MISMATCH"
    if re.search(
        r"\brewards?\b|\bNSU\b|\bnew\s+reward\s+sign[-\s]?ups?\b|\bLMR\b|"
        r"\bloyalty\s+customer\s+number\b",
        text,
        flags=re.IGNORECASE,
    ):
        return "Rewards"
    return None


def _store_operations_category(
    text: str,
    model_issue_category: Optional[str],
) -> Optional[str]:
    """Identify the configured Store Operations subcategory."""
    model_category = _clean_scalar(model_issue_category)
    normalized_model = model_category.casefold().replace("_", " ") if model_category else ""
    if normalized_model in {
        "store tax issue",
        "tax charge issue",
        "incorrect tax calculation",
        "wrong tax percentage",
        "tax refund issue",
        "pos tax issue",
    }:
        return "STORE_TAX_ISSUE"
    if normalized_model in {
        "store deposit information issue",
        "deposit information issue",
        "deposit not transmitting",
        "deposit data transmission failure",
    }:
        return "STORE_DEPOSIT_ISSUE"
    if normalized_model in {
        "incorrect manager name on receipts",
        "wrong manager name on receipt",
        "incorrect manager name printed",
        "receipt showing wrong manager",
    }:
        return "STORE_RECEIPT_MANAGER_NAME_ISSUE"
    if re.search(
        r"\btax\b.{0,80}\b(?:charge|calculation|percentage|refund|POS)\b|"
        r"\b(?:charge|calculation|percentage|refund)\b.{0,80}\btax\b|"
        r"\bPOS\s+tax\b",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        return "STORE_TAX_ISSUE"
    if re.search(
        r"\bdeposit\b.{0,100}\b(?:information|transmit|transmission|failure|not\s+transmitting)\b|"
        r"\b(?:information|transmit|transmission|failure)\b.{0,100}\bdeposit\b",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        return "STORE_DEPOSIT_ISSUE"
    if re.search(
        r"\b(?:wrong|incorrect)\b.{0,60}\bmanager\s+name\b.{0,60}\breceipt|\b"
        r"manager\s+name\b.{0,60}\b(?:printed|receipt)\b|"
        r"\breceipt\b.{0,60}\b(?:wrong|incorrect)\s+manager\b",
        text,
        flags=re.IGNORECASE | re.DOTALL,
    ):
        return "STORE_RECEIPT_MANAGER_NAME_ISSUE"
    return None


def _field_present(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    return bool(value)


def _question_for(field: str, templates: dict[str, str]) -> str:
    return templates.get(field, f"Please provide the missing {field.replace('_', ' ')}.")


def _source_contains_value(documents: list[dict[str, str]], value: str) -> bool:
    lowered = value.lower()
    return any(lowered in document.get("text", "").lower() for document in documents)


def _entity_value_is_supported(
    value: Any,
    documents: list[dict[str, str]],
) -> bool:
    if value is None:
        return False
    if isinstance(value, (list, tuple, set)):
        return bool(value) and all(
            _entity_value_is_supported(item, documents)
            for item in value
        )
    if isinstance(value, dict):
        return bool(value) and all(
            _entity_value_is_supported(item, documents)
            for item in value.values()
        )
    text = str(value).strip()
    return bool(text) and _source_contains_value(documents, text)


def build_assessment(
    model_payload: Optional[ExtractionPayload],
    *,
    documents: list[dict[str, str]],
    authoritative: dict[str, Any],
    corrections: Optional[dict[str, Any]] = None,
    rules: Optional[dict[str, Any]] = None,
    entity_config: Optional[dict[str, Any]] = None,
    model_failure: Optional[str] = None,
) -> ExtractionPayload:
    """Merge model output with evidence-driven rules and decide readiness."""
    rules = rules or {}
    entity_config = entity_config if entity_config is not None else load_entity_config()
    corrections = corrections or {}
    store_pattern = DEFAULT_STORE_EMAIL_PATTERN
    templates: dict[str, str] = {}
    invalid_templates: dict[str, str] = {}
    base = model_payload or ExtractionPayload()
    details = base.retail_details
    text = _all_documents_text(documents)

    store_candidates, email_evidence, store_email = _extract_store_candidates(documents, store_pattern)
    candidate_stores = list(store_candidates)
    store_conflict = len(candidate_stores) > 1
    kiosk_candidates, kiosk_evidence = _extract_kiosk_candidates(documents)
    kiosk_number: Optional[str] = kiosk_candidates[0] if len(kiosk_candidates) == 1 else None
    if kiosk_number is None:
        model_kiosk = _clean_scalar(details.kiosk_number)
        if (
            model_kiosk
            and re.fullmatch(r"\d{2,3}", model_kiosk)
            and _source_contains_value(documents, model_kiosk)
        ):
            kiosk_number = model_kiosk
    if kiosk_number is None:
        for item in base.entities:
            if not isinstance(item.entity, str) or item.entity.casefold() != "kiosk_number":
                continue
            model_kiosk = _clean_scalar(item.value)
            if (
                model_kiosk
                and re.fullmatch(r"\d{2,3}", model_kiosk)
                and _source_contains_value(documents, model_kiosk)
            ):
                kiosk_number = model_kiosk
                break
    explicit_store_values = [
        entry.extracted_value
        for store, entries in store_candidates.items()
        for entry in entries
        if any(token in entry.supporting_text.lower() for token in ("store", "location", "site"))
    ]
    explicit_store_values = _unique(str(value) for value in explicit_store_values if value)

    store_number: Optional[str] = None
    if not store_conflict and candidate_stores:
        store_number = candidate_stores[0]
    elif not store_conflict:
        model_store = _clean_scalar(details.store_number)
        if model_store and re.fullmatch(r"\d{4}", model_store) and _source_contains_value(documents, model_store):
            store_number = model_store

    reliable_dates, ambiguous_dates = _date_candidates(documents)
    date_values = _unique(item[0] for item in reliable_dates)
    date_conflict = len(date_values) > 1
    report_date = date_values[0] if len(date_values) == 1 else None
    if not date_conflict and not report_date:
        model_date = _clean_scalar(details.report_business_date)
        if model_date:
            normalized, ambiguous = _date_parse(model_date)
            if normalized and not ambiguous and _source_contains_value(documents, model_date):
                report_date = normalized

    sku_matches = _extract_skus(documents)
    sku_values = _unique(item[0] for item in sku_matches)
    sku_invalid = False
    if not sku_values and details.sku_ids:
        model_skus = [str(value).strip() for value in details.sku_ids if str(value).strip()]
        if all(re.fullmatch(r"\d{2}", value) for value in model_skus):
            model_evidence = any(
                evidence.field_name == "sku_ids"
                and re.search(r"\bsku\b|\bitem\b|\bidentifier\b", evidence.supporting_text, re.IGNORECASE)
                for evidence in base.evidence
            )
            if model_evidence:
                sku_values = _unique(model_skus)
            else:
                sku_invalid = True
        elif model_skus:
            sku_invalid = True

    sco_eod_related = _is_sco_eod(text) or bool(details.sco_eod_related)
    report_name = _clean_scalar(details.report_name) or _infer_report_name(text, sco_eod_related)
    missing_item = _clean_scalar(details.missing_item) or _infer_missing_item(text)
    store_email_value = store_email or _clean_scalar(details.store_email)
    if store_email_value and not EMAIL_PATTERN.fullmatch(store_email_value):
        store_email_value = None

    evidence_business_area = _infer_business_area(
        text,
        entity_config,
        authoritative.get("group_id"),
    )
    business_area = (
        evidence_business_area
        if evidence_business_area != "Unknown"
        else _clean_scalar(base.classification.business_area) or "Unknown"
    )
    wms_identifiers, wms_identifier_evidence = (
        _extract_wms_identifiers(documents)
        if business_area in {"WMS", "Warehouse", "Warehouse/Distribution"}
        else ({}, [])
    )
    request_type = (
        _clean_scalar(base.classification.request_type)
        or _infer_request_type(text)
    )
    affected_system = _clean_scalar(base.classification.affected_system)
    model_issue_category = _clean_scalar(base.classification.issue_category)
    bi_mars_category = (
        _bi_mars_category(text, model_issue_category)
        if business_area == "BI Reports"
        else None
    )
    store_operations_category = (
        _store_operations_category(text, model_issue_category)
        if business_area == "Store Operations"
        else None
    )
    configured_category = _configured_area_category(
        text,
        model_issue_category,
        business_area,
        entity_config,
    )
    model_dc_name = _model_entity_value(
        base.entities,
        "dc_name",
        "DC name",
        "distribution center name",
        "distribution centre name",
        "warehouse name",
    )
    dc_name = _clean_scalar(wms_identifiers.get("dc_name")) or (
        _clean_scalar(model_dc_name)
        if _entity_value_is_supported(model_dc_name, documents)
        else None
    )
    detected_issue_category = _category_for_business_area(business_area)
    normalized_model_category = re.sub(
        r"[^a-z0-9]+",
        " ",
        (model_issue_category or "").casefold(),
    ).strip()
    issue_category = (
        bi_mars_category
        or store_operations_category
        or configured_category
        or (
            detected_issue_category
            if normalized_model_category not in {"unknown", "none"}
            else None
        )
        or "UNKNOWN"
    )
    incident_type = _clean_scalar(base.classification.incident_type) or (
        "Missing report"
        if issue_category in {"missing_report", "sco_eod_missing_report"}
        else "Retail incident"
    )
    user_intent = _clean_scalar(base.classification.user_intent)
    if not user_intent and missing_item:
        user_intent = "Investigate and restore the missing BI/MARS report or data."
    elif not user_intent and report_name:
        user_intent = f"Investigate the {report_name} issue."
    elif not user_intent and business_area != "Unknown":
        user_intent = f"Investigate the {business_area} incident."
    summary = _clean_scalar(base.classification.summary)
    if summary and summary.casefold() == (
        "the ticket requires bi/mars incident intake clarification.".casefold()
    ):
        summary = None
    if not summary:
        if _is_missing_report(text) or missing_item:
            summary = (
                f"{report_name or f'{business_area} report'} is not available"
                f"{f' for store {store_number}' if store_number else ''}."
            )
        else:
            subject = _clean_scalar(authoritative.get("subject"))
            if subject:
                summary = f"{business_area} incident: {subject}."
            else:
                summary = f"A {business_area} incident was reported."
    expected_outcome = _clean_scalar(base.classification.expected_outcome) or (
        "Identify the cause and resolve the reported incident or provide the requested outcome."
    )
    requested_action = _clean_scalar(base.classification.requested_action) or user_intent

    # Analyst corrections are deliberately treated as a separate evidence source.
    invalid_fields: list[str] = []
    correction_store = _clean_scalar(corrections.get("store_number"))
    if correction_store is not None:
        if re.fullmatch(r"\d{4}", correction_store):
            store_number = correction_store
            store_conflict = False
        else:
            invalid_fields.append("store_number")
    correction_date = _clean_scalar(corrections.get("report_business_date"))
    if correction_date is not None:
        normalized, ambiguous = _date_parse(correction_date)
        if normalized and not ambiguous:
            report_date = normalized
            date_conflict = False
            date_values = [normalized]
        else:
            invalid_fields.append("report_business_date")
    correction_report = _clean_scalar(corrections.get("report_name"))
    if correction_report is not None:
        report_name = correction_report
    correction_missing = _clean_scalar(corrections.get("missing_item"))
    if correction_missing is not None:
        missing_item = correction_missing
    correction_intent = _clean_scalar(corrections.get("user_intent"))
    if correction_intent is not None:
        user_intent = correction_intent
    correction_error = _clean_scalar(corrections.get("error_message"))
    error_message = correction_error or _clean_scalar(details.error_message)
    correction_skus = corrections.get("sku_ids")
    if correction_skus not in (None, ""):
        if isinstance(correction_skus, str):
            correction_skus = re.findall(r"(?<!\d)\d{2}(?!\d)", correction_skus)
        if isinstance(correction_skus, list) and all(re.fullmatch(r"\d{2}", str(item).strip()) for item in correction_skus):
            sku_values = _unique(str(item).strip() for item in correction_skus)
            sku_invalid = False
        else:
            sku_invalid = True

    if store_conflict:
        invalid_fields = [field for field in invalid_fields if field != "store_number"]
    if details.store_number and not re.fullmatch(r"\d{4}", str(details.store_number)):
        if not candidate_stores and "store_number" not in invalid_fields:
            invalid_fields.append("store_number")
    if details.report_business_date and not report_date and not date_conflict and not ambiguous_dates:
        if "report_business_date" not in invalid_fields:
            invalid_fields.append("report_business_date")
    if sku_invalid and "sku_ids" not in invalid_fields:
        invalid_fields.append("sku_ids")

    conflicting_fields: list[str] = []
    if store_conflict:
        conflicting_fields.append("store_number")
    if date_conflict:
        conflicting_fields.append("report_business_date")
    if any(
        entry.field_name == "store_number"
        and entry.extracted_value
        and str(entry.extracted_value) not in candidate_stores
        for entry in base.evidence
    ):
        conflicting_fields.append("store_number")
    conflicting_fields = _unique(conflicting_fields)

    ambiguous_fields: list[str] = []
    if ambiguous_dates:
        ambiguous_fields.append("report_business_date")
    if len(candidate_stores) > 1:
        ambiguous_fields.append("store_number")
    ambiguous_fields = _unique(ambiguous_fields)

    values: dict[str, Any] = {
        "subject": authoritative.get("subject"),
        "requester_email": authoritative.get("requester_email"),
        "priority": authoritative.get("priority"),
        "business_area": business_area,
        "summary": summary,
        "requested_action": requested_action,
        "issue_category": issue_category,
        "store_number": store_number if not store_conflict else None,
        "kiosk_number": kiosk_number,
        "report_business_date": report_date if not date_conflict else None,
        "report_name": report_name,
        "missing_item": missing_item,
        "user_intent": user_intent,
        "sku_ids": sku_values,
        "store_email": store_email_value,
        "error_message": error_message,
        "dc_name": dc_name,
    }
    categories = {
        "SCO_EOD": {
            "required_fields": ["store_number", "report_business_date", "report_name", "missing_item"],
            "optional_fields": ["sku_ids", "error_message", "store_email"],
        },
        "missing_report": {
            "required_fields": ["store_number", "report_business_date", "report_name", "missing_item"],
            "optional_fields": ["sku_ids", "error_message", "store_email"],
        },
        "store_reporting_issue": {
            "required_fields": ["store_number", "user_intent"],
            "optional_fields": ["report_business_date", "report_name", "sku_ids", "error_message"],
        },
        "merchandising_incident": {"required_fields": ["user_intent"], "optional_fields": ["sku_ids", "error_message"]},
        "tam_incident": {"required_fields": ["user_intent"], "optional_fields": ["affected_system", "error_message"]},
        "warehouse_incident": {"required_fields": ["user_intent"], "optional_fields": ["affected_system", "error_message"]},
        "wms_incident": {"required_fields": ["user_intent"], "optional_fields": ["affected_system", "error_message"]},
        "SUPPLY_CHAIN_PICK_LIST_ISSUE": {
            "required_fields": [],
            "optional_fields": [
                "dc_number",
                "list_id",
                "wave_number",
                "pick_type",
                "item_number",
                "pick_quantity",
                "pick_status",
                "ptl_confirmation_status",
            ],
        },
        "LOAD_STOP_ISSUE": {
            "required_fields": [],
            "optional_fields": ["warehouse_number", "load_id", "trailer_number", "stop_id", "store_number"],
        },
        "STORE_MANIFEST_REPORT": {
            "required_fields": [],
            "optional_fields": ["warehouse_number", "store_number", "load_id", "trailer_number"],
        },
        "TRAILER_CLOSE_ISSUE": {
            "required_fields": [],
            "optional_fields": ["warehouse_number", "trailer_number", "load_id"],
        },
        "CMV_LOAD_COMPLETE_ISSUE": {
            "required_fields": [],
            "optional_fields": ["warehouse_number", "shipment_id", "carmove_id"],
        },
        "rms_incident": {"required_fields": ["user_intent"], "optional_fields": ["affected_system", "sku_ids", "error_message"]},
        "loyalty_incident": {"required_fields": ["user_intent"], "optional_fields": ["affected_system", "error_message"]},
        "store_operations_incident": {
            "required_fields": ["user_intent"],
            "optional_fields": ["store_number", "error_message"],
        },
        "STORE_TAX_ISSUE": {
            "required_fields": ["user_intent"],
            "optional_fields": ["store_number", "error_message"],
        },
        "STORE_DEPOSIT_ISSUE": {
            "required_fields": ["user_intent"],
            "optional_fields": ["store_number", "error_message"],
        },
        "STORE_RECEIPT_MANAGER_NAME_ISSUE": {
            "required_fields": ["user_intent"],
            "optional_fields": ["store_number", "error_message"],
        },
        "JDA_SALES_MISMATCH": {
            "required_fields": ["user_intent"],
            "optional_fields": [
                "store_number",
                "report_business_date",
                "sku_ids",
                "error_message",
            ],
        },
        "retail_incident": {"required_fields": ["user_intent"], "optional_fields": ["store_number", "error_message"]},
        "UNKNOWN": {"required_fields": ["user_intent"], "optional_fields": ["error_message"]},
    }
    category_rules = categories.get(
        issue_category,
        categories.get("UNKNOWN", {}),
    )
    required_fields = category_rules.get("required_fields", [])
    optional_fields = category_rules.get("optional_fields", [])
    missing_required = [
        field
        for field in required_fields
        if not _field_present(values.get(field))
        and field not in invalid_fields
        and field not in conflicting_fields
        and field not in ambiguous_fields
    ]
    optional_missing = [field for field in optional_fields if not _field_present(values.get(field))]

    evidence = list(base.evidence)
    for store, entries in store_candidates.items():
        evidence.extend(entries)
    evidence.extend(email_evidence)
    for normalized, document, window in reliable_dates:
        evidence.append(
            _evidence(
                "report_business_date",
                normalized,
                document,
                supporting_text=window,
            )
        )
    for raw, document, window in ambiguous_dates:
        evidence.append(
            _evidence("report_business_date", raw, document, supporting_text=window)
        )
    for kiosk, document, supporting_text in kiosk_evidence:
        evidence.append(
            _evidence(
                "kiosk_number",
                kiosk,
                document,
                supporting_text=supporting_text,
            )
        )
    for sku, document, supporting_text in sku_matches:
        evidence.append(_evidence("sku_ids", sku, document, supporting_text=supporting_text))
    for field_name, value in (
        ("report_name", report_name),
        ("missing_item", missing_item),
        ("user_intent", user_intent),
        ("error_message", error_message),
        ("dc_name", dc_name),
    ):
        if value and _source_contains_value(documents, str(value)):
            for document in documents:
                if str(value).lower() in document.get("text", "").lower():
                    evidence.append(_evidence(field_name, value, document))
                    break
    evidence.extend(wms_identifier_evidence)
    for field_name, value in corrections.items():
        if value not in (None, "", []):
            evidence.append(
                EvidenceEntry(
                    field_name=field_name,
                    extracted_value=value,
                    source_location=f"analyst_correction.{field_name}",
                    source="analyst_correction",
                    supporting_text=str(value),
                )
            )

    # De-duplicate evidence while preserving source order.
    deduplicated: list[EvidenceEntry] = []
    evidence_keys: set[tuple[str, str, str, str]] = set()
    for item in evidence:
        key = (
            item.field_name,
            str(item.extracted_value),
            item.source_location,
            item.supporting_text,
        )
        if key not in evidence_keys:
            evidence_keys.add(key)
            deduplicated.append(item)

    validation = ValidationSummary(
        missing_required_fields=_unique(missing_required),
        invalid_fields=_unique(invalid_fields),
        ambiguous_fields=ambiguous_fields,
        conflicting_fields=conflicting_fields,
        optional_missing_fields=_unique(optional_missing),
    )

    clarification_questions: list[str] = []
    for field in validation.conflicting_fields:
        if field == "store_number" and candidate_stores:
            clarification_questions.append(
                f"I found different store numbers ({', '.join(candidate_stores)}). Which four-digit store number is correct?"
            )
        elif field == "report_business_date" and date_values:
            clarification_questions.append(
                f"I found different report dates ({', '.join(date_values)}). Which business/reporting date is correct?"
            )
        else:
            clarification_questions.append(f"Which value is correct for {field.replace('_', ' ')}?")
    for field in validation.invalid_fields:
        question = invalid_templates.get(field)
        if question:
            clarification_questions.append(question)
    for field in validation.ambiguous_fields:
        if field not in validation.conflicting_fields:
            clarification_questions.append(_question_for(field, templates))
    for field in validation.missing_required_fields:
        clarification_questions.append(_question_for(field, templates))
    clarification_questions = _unique(clarification_questions)

    if clarification_questions:
        if conflicting_fields:
            clarification_intro = "I found conflicting information in the incident."
        elif invalid_fields:
            clarification_intro = "Some incident details need correction."
        else:
            clarification_intro = (
                f"I understand the incident as: "
                f"{(summary or 'a retail support incident').rstrip('.!?')}."
            )
        clarification_message = (
            f"{clarification_intro}\n\n"
            "Please provide or confirm the following required details:\n"
            + "\n".join(
                f"{number}. {question}"
                for number, question in enumerate(clarification_questions, start=1)
            )
        )
    else:
        clarification_message = "All configured mandatory incident details are present and valid."

    if conflicting_fields:
        status = "CONFLICTING_INFORMATION"
    elif invalid_fields:
        status = "INVALID_DATA"
    elif missing_required:
        status = "NEEDS_CLARIFICATION"
    elif model_failure:
        status = "ANALYSIS_FAILED"
    else:
        status = "READY_FOR_INVESTIGATION"
    if model_failure:
        # A model failure must never be shown as a successful intake assessment.
        status = "ANALYSIS_FAILED"

    next_steps: list[str] = []
    if status == "READY_FOR_INVESTIGATION":
        next_steps = [
            "Begin technical investigation using the stated store, report, and business date.",
            "Verify the report/file/data availability without assuming an ETL or load failure.",
        ]
    elif status == "ANALYSIS_FAILED":
        next_steps = [
            "Retry extraction after confirming that LM Studio is running and the configured model is loaded."
        ]
    else:
        next_steps = ["Resolve the listed intake questions, then reanalyze the incident."]

    configured_fields = configured_entity_fields(
        entity_config,
        business_area,
        freshservice_group_id=authoritative.get("group_id"),
        incident_category=issue_category,
    )
    configured_names: dict[str, str] = {}
    for field in configured_fields:
        field_name = field.get("name")
        if not isinstance(field_name, str) or not field_name.strip():
            continue
        canonical = field_name.strip()
        labels = [canonical, *(field.get("aliases") or [])]
        for label in labels:
            if isinstance(label, str) and label.strip():
                configured_names[
                    re.sub(r"[^a-z0-9]+", "_", label.casefold()).strip("_")
                ] = canonical

    merged_entities = []
    for entity in base.entities:
        normalized_name = (
            re.sub(r"[^a-z0-9]+", "_", entity.entity.casefold()).strip("_")
            if isinstance(entity.entity, str)
            else ""
        )
        if (
            configured_names.get(normalized_name)
            and _entity_value_is_supported(entity.value, documents)
        ):
            merged_entities.append(
                EntityValue(
                    entity=configured_names[normalized_name],
                    value=entity.value,
                )
            )
    merged_entities.extend(
        EntityValue(entity=field_name, value=value)
        for field_name, value in wms_identifiers.items()
        if field_name in configured_names.values()
    )

    payload = ExtractionPayload(
        incident=IncidentMetadata(
            ticket_id=str(authoritative.get("ticket_id")) if authoritative.get("ticket_id") is not None else None,
            display_id=str(authoritative.get("display_id")) if authoritative.get("display_id") is not None else None,
            subject=str(authoritative.get("subject") or ""),
            requester_name=_clean_scalar(authoritative.get("requester_name")),
            requester_email=_clean_scalar(authoritative.get("requester_email")),
            status=_clean_scalar(authoritative.get("status")),
            priority=_clean_scalar(authoritative.get("priority")),
        ),
        classification=Classification(
            domain="BI/MARS",
            business_area=business_area or "Unknown",
            incident_type=incident_type,
            issue_category=issue_category,
            request_type=request_type,
            affected_system=affected_system,
            user_intent=user_intent or "",
            summary=summary or "",
            requested_action=requested_action or "",
            expected_outcome=expected_outcome or "",
        ),
        retail_details=RetailDetails(
            store_number=store_number,
            kiosk_number=kiosk_number,
            store_email=store_email_value,
            sco_eod_related=sco_eod_related,
            report_name=report_name,
            report_business_date=report_date,
            sku_ids=sku_values,
            affected_stores=candidate_stores,
            missing_item=missing_item,
            error_message=error_message,
            additional_identifiers=details.additional_identifiers,
        ),
        entities=merged_entities,
        evidence=deduplicated,
        validation=validation,
        clarification=Clarification(
            required=bool(clarification_questions),
            questions=clarification_questions,
            message=clarification_message,
            reason=(
                "The incident contains conflicting or incomplete required business information."
                if clarification_questions
                else "All configured mandatory intake fields are present and valid."
            ),
        ),
        assessment=Assessment(
            intake_status=status,
            ready_for_investigation=status == "READY_FOR_INVESTIGATION",
            next_steps=next_steps,
        ),
        model_metadata=base.model_metadata,
    )
    return payload
