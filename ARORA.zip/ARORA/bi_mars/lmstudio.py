"""Local LM Studio inference through its OpenAI-compatible API."""

from __future__ import annotations

import base64
import time
from typing import Any, Optional
from urllib.parse import urlparse

import requests

from .attachments import ImageInput
from .config import Settings
from .model_client import (
    ModelConfigurationError,
    ModelDeadlineExceeded,
    ModelHealth,
    ModelInvalidResponse,
    ModelUnavailable,
    parse_model_response,
)


class LMStudioClient:
    """Lazy client for a localhost LM Studio OpenAI-compatible server."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._client: Any = None

    @property
    def configured(self) -> bool:
        return bool(self.settings.lmstudio_model)

    def _base_url(self) -> str:
        parsed = urlparse(self.settings.lmstudio_base_url)
        if parsed.scheme not in {"http", "https"} or parsed.hostname not in {
            "127.0.0.1",
            "localhost",
            "::1",
        }:
            raise ModelConfigurationError(
                "LMSTUDIO_BASE_URL must point to the local LM Studio service."
            )
        return self.settings.lmstudio_base_url.rstrip("/")

    def _timeout(self, deadline: Optional[float]) -> float:
        configured = self.settings.lmstudio_timeout_seconds
        if deadline is None:
            return configured
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise ModelDeadlineExceeded()
        return max(0.01, min(configured, remaining))

    def _get_client(self, timeout: float) -> Any:
        if not self.configured:
            raise ModelConfigurationError(
                "Set LMSTUDIO_MODEL to the loaded LM Studio model."
            )
        if self._client is None:
            try:
                from openai import OpenAI
            except ImportError as exc:
                raise ModelConfigurationError(
                    "Install the project requirements to use the LM Studio provider."
                ) from exc
            self._client = OpenAI(
                api_key=self.settings.lmstudio_api_key or "lm-studio",
                base_url=self._base_url(),
                timeout=timeout,
                max_retries=0,
            )
        return self._client

    def health(self, *, deadline: Optional[float] = None) -> ModelHealth:
        try:
            response = requests.get(
                f"{self._base_url()}/models",
                headers={"Authorization": f"Bearer {self.settings.lmstudio_api_key or 'lm-studio'}"},
                timeout=self._timeout(deadline),
            )
            if response.status_code != 200:
                return ModelHealth(
                    False,
                    False,
                    self.settings.lmstudio_model,
                    "lmstudio",
                    f"LM Studio returned HTTP {response.status_code}.",
                )
            body = response.json()
            models = body.get("data", []) if isinstance(body, dict) else []
            names = {
                item.get("id")
                for item in models
                if isinstance(item, dict) and isinstance(item.get("id"), str)
            }
            if self.settings.lmstudio_model not in names:
                return ModelHealth(
                    True,
                    False,
                    self.settings.lmstudio_model,
                    "lmstudio",
                    f"Model '{self.settings.lmstudio_model}' is not loaded in LM Studio.",
                )
        except ModelConfigurationError as exc:
            return ModelHealth(
                False,
                False,
                self.settings.lmstudio_model,
                "lmstudio",
                str(exc),
            )
        except (requests.RequestException, ValueError) as exc:
            return ModelHealth(
                False,
                False,
                self.settings.lmstudio_model,
                "lmstudio",
                f"Local LM Studio is unavailable ({type(exc).__name__}).",
            )
        return ModelHealth(
            True,
            True,
            self.settings.lmstudio_model,
            "lmstudio",
            "Local LM Studio model is available.",
        )

    @staticmethod
    def _messages(
        prompt: str,
        images: Optional[list[ImageInput]],
    ) -> list[dict[str, Any]]:
        if not images:
            return [{"role": "user", "content": prompt}]
        content: list[dict[str, Any]] = [{"type": "text", "text": prompt}]
        for image in images:
            encoded = base64.b64encode(image.data).decode("ascii")
            content.append(
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:{image.content_type};base64,{encoded}",
                    },
                }
            )
        return [{"role": "user", "content": content}]

    def extract(
        self,
        prompt: str,
        *,
        schema: dict[str, Any],
        deadline: Optional[float] = None,
        strict_retry: bool = False,
        images: Optional[list[ImageInput]] = None,
    ) -> tuple[Any, dict[str, Any]]:
        del schema
        if strict_retry:
            prompt = (
                f"{prompt}\n\nThe previous response was invalid. "
                "Return exactly one complete JSON object and no markdown."
            )
        else:
            prompt = (
                f"{prompt}\n\nOutput contract: return JSON only with "
                '`classification` containing `business_area` and `issue_category`, '
                'plus an `entities` array of `{"entity": "...", "value": "..."}`. '
                "Do not explain your answer."
            )
        started = time.monotonic()
        timeout = self._timeout(deadline)
        client = self._get_client(timeout)
        try:
            response = client.chat.completions.create(
                model=self.settings.lmstudio_model,
                messages=self._messages(prompt, images),
                temperature=0,
                max_tokens=self.settings.lmstudio_max_tokens,
                reasoning_effort=self.settings.lmstudio_reasoning_effort,
                timeout=timeout,
            )
        except ModelConfigurationError:
            raise
        except Exception as exc:
            if deadline is not None and time.monotonic() >= deadline:
                raise ModelDeadlineExceeded() from exc
            raise ModelUnavailable(
                f"Local LM Studio extraction failed ({type(exc).__name__}).",
                code="LMSTUDIO_UNAVAILABLE",
            ) from exc
        if deadline is not None and time.monotonic() >= deadline:
            raise ModelDeadlineExceeded()

        choices = getattr(response, "choices", None)
        message = choices[0].message if choices else None
        raw_output = getattr(message, "content", None)
        if not isinstance(raw_output, str) or not raw_output.strip():
            raise ModelInvalidResponse("LM Studio returned an empty model response.")
        model_payload, generated_text = parse_model_response(raw_output)

        metrics: dict[str, Any] = {
            "latency_ms": round((time.monotonic() - started) * 1000, 1),
            "provider": "lmstudio",
            "model_name": self.settings.lmstudio_model,
            "raw_output": generated_text,
        }
        usage = getattr(response, "usage", None)
        for output_key, usage_key in (
            ("prompt_tokens", "prompt_tokens"),
            ("completion_tokens", "completion_tokens"),
            ("total_tokens", "total_tokens"),
        ):
            value = getattr(usage, usage_key, None)
            if isinstance(value, int):
                metrics[output_key] = value
        return model_payload, metrics
