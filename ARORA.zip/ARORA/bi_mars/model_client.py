"""Shared model-client contract, prompt construction, and response parsing."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Protocol

from .attachments import ImageInput
from .models import ExtractionPayload
from .text import extract_json_object


class ModelError(RuntimeError):
    """Base error for local LM Studio inference."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "MODEL_ERROR",
        stage: str = "model",
    ) -> None:
        super().__init__(message)
        self.code = code
        self.stage = stage


class ModelConfigurationError(ModelError):
    def __init__(self, message: str = "Local model inference is not configured.") -> None:
        super().__init__(message, code="MODEL_NOT_CONFIGURED", stage="model_configuration")


class ModelUnavailable(ModelError):
    def __init__(
        self,
        message: str = "The configured local model is unavailable.",
        *,
        code: str = "MODEL_UNAVAILABLE",
        stage: str = "model_inference",
    ) -> None:
        super().__init__(message, code=code, stage=stage)


class ModelDeadlineExceeded(ModelError):
    def __init__(self, stage: str = "model_inference") -> None:
        super().__init__(
            "The analysis deadline was reached during local model inference.",
            code="ANALYSIS_DEADLINE_EXCEEDED",
            stage=stage,
        )


class ModelInvalidResponse(ModelError):
    def __init__(self, message: str = "NuExtract3 did not return valid JSON.") -> None:
        super().__init__(
            message,
            code="MODEL_INVALID_RESPONSE",
            stage="model_inference",
        )


@dataclass(frozen=True)
class ModelHealth:
    reachable: bool
    model_available: bool
    configured_model: str
    provider: str
    message: str = ""


class ModelClient(Protocol):
    def extract(
        self,
        prompt: str,
        *,
        schema: dict[str, Any],
        deadline: Optional[float] = None,
        strict_retry: bool = False,
        images: Optional[list[ImageInput]] = None,
    ) -> tuple[ExtractionPayload, dict[str, Any]]:
        ...


def parse_model_response(raw_output: str) -> tuple[ExtractionPayload, str]:
    generated_text = raw_output.strip()
    try:
        parsed = extract_json_object(generated_text)
        payload = ExtractionPayload.model_validate(_omit_null_values(parsed))
    except (ValueError, TypeError) as exc:
        raise ModelInvalidResponse() from exc
    return payload, generated_text


def _omit_null_values(value: Any) -> Any:
    """Let omitted model fields use the contract's defaults."""
    if isinstance(value, dict):
        return {
            key: _omit_null_values(item)
            for key, item in value.items()
            if item is not None
        }
    if isinstance(value, list):
        return [_omit_null_values(item) for item in value if item is not None]
    return value


def create_model_client(settings: Any) -> ModelClient:
    """Create the configured LM Studio client."""
    if settings.model_provider != "lmstudio":
        raise ModelConfigurationError("LM Studio is the only supported model provider.")
    from .lmstudio import LMStudioClient

    return LMStudioClient(settings)
