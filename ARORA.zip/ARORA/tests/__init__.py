"""Synthetic tests for BI/MARS Incident Intelligence."""
