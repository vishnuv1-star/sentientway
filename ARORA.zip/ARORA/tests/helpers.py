from __future__ import annotations

from pathlib import Path
from typing import Any

from bi_mars.config import load_settings
from bi_mars.models import ExtractionPayload, TicketContext


ROOT = Path(__file__).resolve().parents[1]


def docs(*items: tuple[str, str, str]) -> list[dict[str, str]]:
    return [
        {"source": source, "source_location": location, "text": text}
        for source, location, text in items
    ]


def authority(**overrides: Any) -> dict[str, Any]:
    value = {
        "ticket_id": "10001",
        "display_id": "INC-10001",
        "subject": "Synthetic BI/MARS incident",
        "requester_name": "Synthetic Requester",
        "requester_email": "requester@michaels.com",
        "status": "Open",
        "priority": "High",
    }
    value.update(overrides)
    return value


def complete_payload() -> ExtractionPayload:
    return ExtractionPayload(
        classification={
            "incident_type": "Missing report",
            "issue_category": "sco_eod_missing_report",
            "user_intent": "Investigate the missing report.",
            "summary": "The report is missing.",
            "expected_outcome": "Restore the report.",
        },
        retail_details={
            "sco_eod_related": True,
            "report_name": "SCO EOD report",
            "report_business_date": "2026-10-28",
            "store_number": "4812",
            "sku_ids": [],
            "missing_item": "missing_report_output",
        },
    )


def settings(tmp_path: Path, **overrides: Any):
    root = tmp_path
    (root / "config").mkdir(parents=True, exist_ok=True)
    (root / "config" / "entity_fields.json").write_text(
        (ROOT / "config" / "entity_fields.json").read_text(encoding="utf-8"),
        encoding="utf-8",
    )
    lines = [
        "FRESHSERVICE_URL=https://synthetic.freshservice.test",
        "FRESHSERVICE_API_KEY=synthetic-secret",
        "FRESHSERVICE_WORKSPACE_ID=2",
        "MODEL_PROVIDER=lmstudio",
        "MODEL_NAME=nuextract3",
        "LMSTUDIO_MODEL=nuextract3",
        "LMSTUDIO_BASE_URL=http://127.0.0.1:1234/v1",
        "LMSTUDIO_API_KEY=lm-studio",
        "MAX_RETRIES=0",
        "RETRY_BACKOFF_SECONDS=0",
    ]
    for key, value in overrides.items():
        lines.append(f"{key}={value}")
    (root / ".env").write_text("\n".join(lines), encoding="utf-8")
    return load_settings(root)


def context(ticket: dict[str, Any] | None = None, conversations: list[dict[str, Any]] | None = None) -> TicketContext:
    base = {
        "id": 10001,
        "display_id": "INC-10001",
        "subject": "Synthetic BI/MARS incident",
        "description": "<p>Synthetic description</p>",
        "description_text": "Synthetic description",
        "requester": {"name": "Synthetic Requester", "email": "requester@michaels.com"},
        "status": 2,
        "priority": 3,
        "custom_fields": {},
    }
    if ticket:
        base.update(ticket)
    return TicketContext(ticket=base, conversations=conversations or [])
