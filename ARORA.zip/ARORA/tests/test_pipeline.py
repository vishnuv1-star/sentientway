from __future__ import annotations

from typing import Any

from bi_mars.freshservice import FreshserviceError
from bi_mars.models import ExtractionPayload
from bi_mars.models import AttachmentDocument
from bi_mars.model_client import (
    ModelDeadlineExceeded,
    ModelInvalidResponse,
    ModelUnavailable,
)
from bi_mars.pipeline import IncidentAnalysisService

from .helpers import authority, complete_payload, context, docs, settings


class StubFreshservice:
    def __init__(self, ticket_context):
        self.ticket_context = ticket_context

    def get_context(self, reference, *, deadline=None, refresh=False):
        return self.ticket_context


class StubModel:
    def __init__(self, behavior):
        self.behavior = behavior
        self.calls: list[dict[str, Any]] = []
        self.image_batches: list[Any] = []

    def extract(self, prompt, *, schema, deadline=None, strict_retry=False, images=None):
        self.calls.append({"prompt": prompt, "strict_retry": strict_retry})
        self.image_batches.append(images)
        if isinstance(self.behavior, list):
            value = self.behavior.pop(0)
        else:
            value = self.behavior
        if isinstance(value, Exception):
            raise value
        return value, {"latency_ms": 1.0, "response_status": 200, "retry_count": 0}


def synthetic_context():
    return context(
        {
            "id": 10001,
            "display_id": "INC-10001",
            "subject": "Missing SCO EOD report",
            "description": "<p>Store 4812 report output missing for business date 2026-10-28.</p>",
            "description_text": "Store 4812 report output missing for business date 2026-10-28.",
            "requester": {"name": "Manager", "email": "sm4812@michaels.com"},
        }
    )


def service(tmp_path, model_client, **settings_overrides):
    config = settings(tmp_path, **settings_overrides)
    return IncidentAnalysisService(
        config,
        StubFreshservice(synthetic_context()),
        model_client,
    )


def test_invalid_model_response_gets_one_strict_retry_and_can_recover(tmp_path):
    client = StubModel([ModelInvalidResponse(), complete_payload()])
    response = service(tmp_path, client).analyze("10001")
    assert response.success is True
    assert len(client.calls) == 2
    assert client.calls[1]["strict_retry"] is True


def test_malformed_or_unavailable_model_preserves_partial_ticket_context(tmp_path):
    client = StubModel(ModelUnavailable("Local model is unavailable"))
    response = service(tmp_path, client).analyze("10001")
    assert response.success is False
    assert response.error.error_code == "MODEL_UNAVAILABLE"
    assert response.error.partial_results_available is True
    assert response.context.ticket["id"] == 10001
    assert response.payload.assessment.intake_status == "ANALYSIS_FAILED"


def test_unexpected_model_error_preserves_partial_assessment(tmp_path):
    response = service(tmp_path, RuntimeError("local model failure")).analyze("10001")

    assert response.success is False
    assert response.error.error_code == "MODEL_UNAVAILABLE"
    assert response.payload is not None
    assert response.payload.incident.subject == "Missing SCO EOD report"
    assert response.payload.assessment.intake_status == "ANALYSIS_FAILED"


def test_deadline_response_is_not_reported_as_success(tmp_path):
    client = StubModel(ModelDeadlineExceeded())
    response = service(tmp_path, client).analyze("10001")
    assert response.success is False
    assert response.error.error_code == "ANALYSIS_DEADLINE_EXCEEDED"
    assert response.error.failed_stage == "model_inference"


def test_authoritative_ticket_metadata_overrides_model_metadata(tmp_path):
    model_payload = complete_payload()
    model_payload.incident.ticket_id = "model-ticket"
    model_payload.incident.display_id = "model-display"
    client = StubModel(model_payload)
    response = service(tmp_path, client).analyze("10001")
    assert response.payload.incident.ticket_id == "10001"
    assert response.payload.incident.display_id == "INC-10001"


def test_prompt_preserves_the_entire_ordered_conversation_flow(tmp_path):
    ticket_context = synthetic_context()
    ticket_context.conversations = [
        {
            "from_email": "store@michaels.com",
            "created_at": "2026-10-28T01:00:00Z",
            "body": "<p>Initial report: the file is missing.</p>",
        },
        {
            "from_email": "resa@michaels.com",
            "created_at": "2026-10-28T02:00:00Z",
            "body": "<p>We need the business date confirmed.</p>",
        },
        {
            "from_email": "store@michaels.com",
            "created_at": "2026-10-28T03:00:00Z",
            "body": "<p>Confirmed: 2026-10-28 and the output is missing.</p>",
        },
    ]
    client = StubModel(complete_payload())
    analysis = IncidentAnalysisService(
        settings(tmp_path),
        StubFreshservice(ticket_context),
        client,
    )

    response = analysis.analyze("10001")

    assert response.success is True
    prompt = client.calls[0]["prompt"]
    assert "CONVERSATION FLOW REQUIREMENT" in prompt
    assert "Freshservice returned 3 conversation message(s)" in prompt
    first = prompt.index("Initial report: the file is missing.")
    second = prompt.index("We need the business date confirmed.")
    third = prompt.index("Confirmed: 2026-10-28 and the output is missing.")
    assert first < second < third


def test_supply_chain_entities_are_requested_from_the_full_conversation(tmp_path):
    ticket_context = synthetic_context()
    ticket_context.ticket["subject"] = "Warehouse pick list is stuck"
    ticket_context.ticket["description_text"] = "The list is not clearing."
    ticket_context.conversations = [
        {
            "from_email": "dc@michaels.com",
            "created_at": "2026-10-28T01:00:00Z",
            "body": "<p>Pick list is stuck and picks are not clearing.</p>",
        },
        {
            "from_email": "dc@michaels.com",
            "created_at": "2026-10-28T02:00:00Z",
            "body": (
                "<p>Confirmed DC name: Dallas DC, DC ID 123456, warehouse 123, "
                "Wave BAT1129058, "
                "LIST ID LST000000782176, item 000123, "
                "pick quantity 12, and PTL confirmation is pending.</p>"
            ),
        },
    ]
    client = StubModel(complete_payload())
    analysis = IncidentAnalysisService(
        settings(tmp_path),
        StubFreshservice(ticket_context),
        client,
    )

    response = analysis.analyze("10001")

    assert response.success is True
    prompt = client.calls[0]["prompt"]
    assert "dc_number" in prompt
    assert "wave_number" in prompt
    assert "list_id" in prompt
    assert "pick_quantity" in prompt
    assert "ptl_confirmation_status" in prompt
    assert "DC ID 123456" in prompt
    assert "DC name: Dallas DC" in prompt
    assert "warehouse 123" in prompt
    assert "Wave BAT1129058" in prompt
    assert "LIST ID LST000000782176" in prompt
    assert "pick quantity 12" in prompt
    assert "PTL confirmation is pending" in prompt


def test_attachment_bytes_are_cleared_after_analysis(tmp_path):
    ticket_context = synthetic_context()
    ticket_context.attachments = [
        AttachmentDocument(
            filename="screen.png",
            content_type="image/png",
            source_location="conversation[1].attachment[1]",
            data=b"screen-bytes",
        )
    ]
    client = StubModel(complete_payload())
    analysis = IncidentAnalysisService(
        settings(tmp_path),
        StubFreshservice(ticket_context),
        client,
    )

    response = analysis.analyze("10001")

    assert response.success is True
    assert response.context.attachments == []
    assert client.image_batches[0] == []


def test_freshservice_failure_is_not_fabricated(tmp_path):
    class FailingFreshservice:
        def get_context(self, reference, *, deadline=None, refresh=False):
            raise FreshserviceError("not authorized", code="FRESHSERVICE_ACCESS_DENIED")

    config = settings(tmp_path)
    client = StubModel(complete_payload())
    analysis = IncidentAnalysisService(config, FailingFreshservice(), client)
    response = analysis.analyze("10001")
    assert response.success is False
    assert response.error.error_code == "FRESHSERVICE_ACCESS_DENIED"
