from __future__ import annotations

import fitz

from bi_mars.attachments import prepare_attachments
from bi_mars.models import AttachmentDocument


def test_image_attachment_is_prepared_for_visual_extraction():
    documents, images, warning = prepare_attachments(
        [
            AttachmentDocument(
                filename="screen.png",
                content_type="image/png",
                source_location="conversation[2].attachment[1]",
                data=b"image-bytes",
            )
        ],
        max_pages=10,
        max_images=5,
    )

    assert documents == []
    assert warning is None
    assert images[0].source_location == "conversation[2].attachment[1]"
    assert images[0].data == b"image-bytes"


def test_unsupported_attachment_is_reported_without_sending_it_as_an_image():
    documents, images, warning = prepare_attachments(
        [
            AttachmentDocument(
                filename="archive.zip",
                content_type="application/zip",
                source_location="ticket.attachment[1]",
                data=b"zip-bytes",
            )
        ],
        max_pages=10,
        max_images=5,
    )

    assert images == []
    assert warning is None
    assert "unsupported content type" in documents[0]["text"]


def test_pdf_pages_are_rendered_for_visual_extraction():
    pdf = fitz.open()
    page = pdf.new_page()
    page.insert_text((72, 72), "Warehouse incident screenshot")
    pdf_bytes = pdf.tobytes()
    pdf.close()

    documents, images, warning = prepare_attachments(
        [
            AttachmentDocument(
                filename="incident.pdf",
                content_type="application/pdf",
                source_location="conversation[4].attachment[1]",
                data=pdf_bytes,
            )
        ],
        max_pages=10,
        max_images=5,
    )

    assert documents == []
    assert warning is None
    assert images[0].filename == "incident.pdf#page-1"
    assert images[0].content_type == "image/png"
    assert images[0].data.startswith(b"\x89PNG")
