from __future__ import annotations

from pathlib import Path

from analyze_incident import _incident_only
from bi_mars.config import configured_entity_fields, load_entity_config


ROOT = Path(__file__).resolve().parents[1]


def test_entity_config_selects_different_fields_for_bi_and_loyalty():
    config = load_entity_config(ROOT)

    sco_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "BI Reports",
            incident_category="sco_eod_missing_report",
        )
    }
    lighthouse_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "BI Reports",
            incident_category="Lighthouse Sales",
        )
    }
    promotion_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "BI Reports",
            incident_category="Pricing / Promotion / POG",
        )
    }
    jda_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "BI Reports",
            incident_category="JDA_SALES_MISMATCH",
        )
    }
    tax_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "Store Operations",
            incident_category="STORE_TAX_ISSUE",
        )
    }
    deposit_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "Store Operations",
            incident_category="STORE_DEPOSIT_ISSUE",
        )
    }
    receipt_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "Store Operations",
            incident_category="STORE_RECEIPT_MANAGER_NAME_ISSUE",
        )
    }
    loyalty_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "Loyalty",
            incident_category="LOYALTY_ACCOUNT_ISSUE",
        )
    }
    supply_chain_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "WMS",
            incident_category="SUPPLY_CHAIN_PICK_LIST_ISSUE",
        )
    }

    assert {"store_number", "kiosk_number", "day_date", "cash_sales"} <= sco_names
    assert "total_sales" not in sco_names
    assert {"day_date", "total_sales", "custom_framing_ontime_percent"} <= lighthouse_names
    assert "reward_signups" not in lighthouse_names
    assert {
        "store_number",
        "barcode",
        "sku",
        "promotion_name",
        "promotion_id",
        "expected_price",
        "actual_pos_price",
        "transaction_id",
        "register_number",
    } <= promotion_names
    assert "total_sales" not in promotion_names
    assert {
        "sku",
        "product_description",
        "store_number",
        "business_date",
        "jda_sales_units",
        "power_bi_sales_units",
        "vendor_connect_sales_units",
        "chain_expansion_date",
        "affected_week",
        "report_url",
    } == jda_names
    assert {
        "store_number",
        "tax_percentage",
        "expected_tax_percentage",
        "transaction_type",
        "transaction_date",
        "transaction_id",
        "register_number",
        "affected_duration",
    } <= tax_names
    assert {
        "store_number",
        "deposit_date",
        "register_number",
        "transmission_status",
        "affected_frequency",
        "workaround_status",
    } <= deposit_names
    assert {
        "store_number",
        "printed_manager_name",
        "expected_manager_name",
        "register_number",
        "transaction_date",
        "transaction_id",
    } <= receipt_names
    assert "member_id" in loyalty_names
    assert "points_or_rewards_issue" in loyalty_names
    assert "report_name" not in loyalty_names
    assert {
        "dc_number",
        "list_id",
        "pick_type",
        "item_number",
        "pick_quantity",
        "pick_status",
        "ptl_confirmation_status",
    } <= supply_chain_names


def test_wms_supply_chain_categories_select_their_entity_sets():
    config = load_entity_config(ROOT)
    expected = {
        "SUPPLY_CHAIN_PICK_LIST_ISSUE": {
            "list_id",
            "wave_number",
            "dc_number",
            "pick_type",
            "item_number",
            "pick_quantity",
            "pick_status",
            "ptl_confirmation_status",
        },
        "LOAD_STOP_ISSUE": {
            "load_id",
            "trailer_number",
            "stop_id",
            "store_number",
        },
        "STORE_MANIFEST_REPORT": {
            "store_number",
            "load_id",
            "trailer_number",
        },
        "TRAILER_CLOSE_ISSUE": {
            "trailer_number",
            "load_id",
        },
        "CMV_LOAD_COMPLETE_ISSUE": {
            "shipment_id",
            "carmove_id",
        },
    }

    for category, names in expected.items():
        fields = configured_entity_fields(
            config,
            "WMS",
            incident_category=category,
        )
        selected = {field["name"] for field in fields}
        assert names <= selected
        assert "error_message" not in selected

    base_fields = configured_entity_fields(
        config,
        "WMS",
        incident_category="SUPPLY_CHAIN_PICK_LIST_ISSUE",
    )
    dc_number = next(field for field in base_fields if field["name"] == "dc_number")
    list_id = next(field for field in base_fields if field["name"] == "list_id")
    assert dc_number["pattern"] == r"^\d{6}$"
    assert list_id["pattern"] == r"^LST\d{12}$"


def test_entity_config_selects_group_by_freshservice_group_id():
    config = load_entity_config(ROOT)

    fields = configured_entity_fields(
        config,
        "Loyalty",
        freshservice_group_id="183613",
        incident_category="SCO EOD",
    )
    names = {field["name"] for field in fields}

    assert "day_date" in names
    assert "kiosk_number" in names
    assert "member_id" not in names


def test_entity_config_uses_default_fields_for_unknown_area():
    config = load_entity_config(ROOT)

    names = {
        field["name"]
        for field in configured_entity_fields(config, "Unknown")
    }

    assert names == set()


def test_error_message_is_not_configured_for_non_supply_chain_areas():
    config = load_entity_config(ROOT)

    names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "BI Reports",
            incident_category="sco_eod_missing_report",
        )
    }

    assert "error_message" not in names


def test_bi_projection_does_not_mix_fields_for_unknown_category():
    config = load_entity_config(ROOT)

    names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "BI Reports",
            incident_category="store_reporting_issue",
        )
    }

    assert names == set()


def test_cli_projection_emits_only_the_selected_group_fields():
    config = load_entity_config(ROOT)
    assessment = {
        "incident": {"subject": "Rewards issue"},
        "classification": {
            "business_area": "Loyalty",
            "issue_category": "LOYALTY_ACCOUNT_ISSUE",
            "summary": "Loyalty incident: Rewards issue.",
            "requested_action": "Investigate the rewards issue.",
        },
        "retail_details": {},
        "entities": [
            {"entity": "member_id", "value": "M-100"},
            {"entity": "warehouse_id", "value": "WH-IGNORE"},
            {"entity": "unconfigured_field", "value": "IGNORE"},
        ],
    }

    output = _incident_only(
        {"assessment": assessment},
        "INC-1",
        entity_config=config,
    )
    actual_names = {next(iter(item)) for item in output["entities"]}
    configured_names = {
        field["name"]
        for field in configured_entity_fields(
            config,
            "Loyalty",
            incident_category="LOYALTY_ACCOUNT_ISSUE",
        )
    }

    assert actual_names == configured_names
    assert "error_message" not in actual_names
    assert "warehouse_id" not in actual_names
    assert "unconfigured_field" not in actual_names


def test_cli_projection_emits_store_tax_entities_from_json_configuration():
    config = load_entity_config(ROOT)
    assessment = {
        "incident": {},
        "classification": {
            "business_area": "Store Operations",
            "issue_category": "STORE_TAX_ISSUE",
        },
        "retail_details": {"store_number": "3992"},
        "entities": [
            {"entity": "tax_percentage", "value": "8.25"},
            {"entity": "transaction_id", "value": "R-100"},
        ],
    }

    output = _incident_only(
        {"assessment": assessment},
        "INC-980709",
        entity_config=config,
    )
    values = {
        name: value
        for item in output["entities"]
        for name, value in item.items()
    }

    assert values["store_number"] == "3992"
    assert values["tax_percentage"] == "8.25"
    assert values["transaction_id"] == "R-100"
    assert "printed_manager_name" not in values


def test_cli_projection_emits_supply_chain_entities_from_json_configuration():
    config = load_entity_config(ROOT)
    assessment = {
        "incident": {},
        "classification": {
            "business_area": "WMS",
            "issue_category": "SUPPLY_CHAIN_PICK_LIST_ISSUE",
        },
        "retail_details": {},
        "entities": [
            {"entity": "DC ID", "value": "123456"},
            {"entity": "LIST ID", "value": "LST000000782176"},
            {"entity": "pick count", "value": 12},
            {"entity": "PTL confirm status", "value": "pending"},
        ],
    }

    output = _incident_only(
        {"assessment": assessment},
        "INC-980710",
        entity_config=config,
    )
    values = {
        name: value
        for item in output["entities"]
        for name, value in item.items()
    }

    assert values["dc_number"] == "123456"
    assert "dc_name" not in values
    assert values["list_id"] == "LST000000782176"
    assert values["pick_quantity"] == 12
    assert values["ptl_confirmation_status"] == "pending"
