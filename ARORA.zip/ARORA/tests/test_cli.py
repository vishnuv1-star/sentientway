from __future__ import annotations

import json

import analyze_incident


def test_cli_prints_analysis_as_json(monkeypatch, capsys):
    monkeypatch.setattr(
        analyze_incident,
        "analyze_incident",
        lambda reference, refresh=False: {
            "success": True,
            "assessment": {
                "incident": {
                    "subject": (
                        "Self-Checkout | 2048 | Store - DFW-FT WORTH/HULEN, TX | "
                        "Kiosk - 51 | Sales Reporting Issue"
                    ),
                    "requester_email": "amy331@michaels.com",
                    "priority": "2",
                },
                "classification": {
                    "business_area": "BI Reports",
                    "issue_category": "sco_eod_missing_report",
                    "user_intent": "Investigate the missing report.",
                    "summary": "The ticket requires BI/MARS incident intake clarification.",
                    "requested_action": "Investigate the sales reporting issue.",
                    "expected_outcome": "Restore the report.",
                },
                "retail_details": {
                    "store_number": "2048",
                    "sku_ids": [],
                },
                "entities": [
                    {"entity": "kiosk_number", "value": None},
                    {"entity": "day_date", "value": None},
                    {"entity": "ticket_id", "value": "976902"},
                ],
            },
        },
    )

    exit_code = analyze_incident.main(["INC-976902"])

    assert exit_code == 0
    output = json.loads(capsys.readouterr().out)
    assert set(output) == {"incident_number", "entities"}
    assert output["incident_number"] == "INC-976902"
    values = {
        name: value
        for item in output["entities"]
        for name, value in item.items()
    }
    assert "requested_action" not in values
    assert "issue_category" not in values
    assert values["store_number"] == "2048"
    assert values["day_date"] is None
    assert values["kiosk_number"] is None
    assert all(set(item) != {"entity", "value"} for item in output["entities"])
    assert "subject" not in values
    assert "business_area" not in values
    assert "summary" not in values
    assert "ticket_id" not in values
    assert "display_id" not in values
    assert "status" not in values
    assert "requester_name" not in values
    assert "validation" not in output
    assert "error_code" not in output


def test_cli_returns_null_for_missing_incident_values(monkeypatch, capsys):
    monkeypatch.setattr(
        analyze_incident,
        "analyze_incident",
        lambda reference: {
            "success": True,
            "assessment": {
                "incident": {},
                "classification": {
                    "business_area": "BI Reports",
                    "issue_category": "sco_eod_missing_report",
                },
                "retail_details": {},
            },
        },
    )

    exit_code = analyze_incident.main(["INC-100"])

    assert exit_code == 0
    output = json.loads(capsys.readouterr().out)
    entities = {
        name: value
        for item in output["entities"]
        for name, value in item.items()
    }
    assert "requested_action" not in entities
    assert "issue_category" not in entities
    assert entities["day_date"] is None
    assert entities["kiosk_number"] is None
    assert entities["cash_sales"] is None


def test_cli_keeps_loyalty_entities_domain_specific(monkeypatch, capsys):
    monkeypatch.setattr(
        analyze_incident,
        "analyze_incident",
        lambda reference: {
            "success": True,
            "assessment": {
                "incident": {
                    "subject": "Rewards points error",
                    "requester_email": "member-support@michaels.com",
                    "priority": "2",
                },
                "classification": {
                    "business_area": "Loyalty",
                    "issue_category": "loyalty_incident",
                    "summary": "Rewards points are not updating.",
                    "requested_action": "Investigate the points issue.",
                },
                "retail_details": {"store_number": "4946"},
                "entities": [
                    {"entity": "member_id", "value": None},
                    {"entity": "loyalty_account_id", "value": None},
                    {"entity": "transaction_id", "value": "TX-123"},
                    {"entity": "points_or_rewards_issue", "value": "points missing"},
                    {"entity": "transaction_date", "value": None},
                ],
            },
        },
    )

    assert analyze_incident.main(["INC-873248"]) == 0
    output = json.loads(capsys.readouterr().out)
    values = {
        name: value
        for item in output["entities"]
        for name, value in item.items()
    }
    assert "business_area" not in values
    assert values["member_id"] is None
    assert values["loyalty_account_id"] is None
    assert values["transaction_id"] == "TX-123"
    assert values["points_or_rewards_issue"] == "points missing"
    assert values["transaction_date"] is None
    assert values["store_number"] == "4946"
    assert "report_name" not in values
    assert "report_business_date" not in values


def test_cli_returns_structured_error_without_incident_number(capsys):
    exit_code = analyze_incident.main([])

    assert exit_code == 2
    output = json.loads(capsys.readouterr().out)
    assert output == {
        "success": False,
        "error_code": "INVALID_TICKET_REFERENCE",
        "failed_stage": "input_validation",
        "partial_results_available": False,
        "message": "Provide a Freshservice incident number, for example INC-976902.",
    }


def test_cli_surfaces_analysis_error_instead_of_hiding_it(monkeypatch, capsys):
    monkeypatch.setattr(
        analyze_incident,
        "analyze_incident",
        lambda reference: {
            "success": False,
            "error_code": "LMSTUDIO_UNAVAILABLE",
            "failed_stage": "model_inference",
            "message": "LM Studio is unavailable.",
        },
    )

    exit_code = analyze_incident.main(["INC-980709"])

    assert exit_code == 1
    output = json.loads(capsys.readouterr().out)
    assert output["entities"] == []
    assert output["error_code"] == "LMSTUDIO_UNAVAILABLE"
    assert output["failed_stage"] == "model_inference"
