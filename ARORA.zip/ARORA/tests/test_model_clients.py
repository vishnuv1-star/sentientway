from __future__ import annotations

import sys
import time
from types import ModuleType, SimpleNamespace

from bi_mars.model_client import (
    create_model_client,
)
from bi_mars.lmstudio import LMStudioClient

from .helpers import settings


class FakeResponse:
    def __init__(self, body, status_code=200):
        self.body = body
        self.status_code = status_code

    def json(self):
        return self.body


def test_default_provider_targets_local_lmstudio_model(tmp_path):
    config = settings(tmp_path)

    assert config.model_provider == "lmstudio"
    assert config.model_name == "nuextract3"
    assert config.lmstudio_model == "nuextract3"
    assert config.lmstudio_base_url == "http://127.0.0.1:1234/v1"


def test_factory_selects_lmstudio_client_by_default(tmp_path):
    client = create_model_client(settings(tmp_path))

    assert isinstance(client, LMStudioClient)


def test_factory_selects_lmstudio_client(tmp_path):
    client = create_model_client(
        settings(
            tmp_path,
            MODEL_PROVIDER="lmstudio",
            MODEL_NAME="nuextract3",
            LMSTUDIO_MODEL="nuextract3",
            LMSTUDIO_BASE_URL="http://127.0.0.1:1234/v1",
        )
    )

    assert isinstance(client, LMStudioClient)


def test_lmstudio_extracts_openai_compatible_response(tmp_path, monkeypatch):
    config = settings(
        tmp_path,
        MODEL_PROVIDER="lmstudio",
        MODEL_NAME="nuextract3",
        LMSTUDIO_MODEL="nuextract3",
        LMSTUDIO_BASE_URL="http://127.0.0.1:1234/v1",
        LMSTUDIO_API_KEY="lm-studio",
        LMSTUDIO_MAX_TOKENS="1000",
    )
    captured: dict[str, object] = {}

    class FakeCompletions:
        def create(self, **kwargs):
            captured.update(kwargs)
            return SimpleNamespace(
                choices=[
                    SimpleNamespace(
                        message=SimpleNamespace(
                            content=(
                                '{"classification":{"issue_category":"STORE_TAX_ISSUE"},'
                                '"entities":[{"entity":"store_number","value":"3755"}]}'
                            )
                        )
                    )
                ],
                usage=SimpleNamespace(
                    prompt_tokens=10,
                    completion_tokens=20,
                    total_tokens=30,
                ),
            )

    class FakeOpenAI:
        def __init__(self, **kwargs):
            captured["client"] = kwargs
            self.chat = SimpleNamespace(completions=FakeCompletions())

    openai_module = ModuleType("openai")
    openai_module.OpenAI = FakeOpenAI
    monkeypatch.setitem(sys.modules, "openai", openai_module)

    payload, metrics = LMStudioClient(config).extract(
        "Extract the incident.",
        schema={"type": "object"},
        deadline=time.monotonic() + 5,
    )

    assert captured["client"]["base_url"] == "http://127.0.0.1:1234/v1"
    assert captured["client"]["api_key"] == "lm-studio"
    assert captured["model"] == "nuextract3"
    assert captured["temperature"] == 0
    assert captured["max_tokens"] == 1000
    assert captured["reasoning_effort"] == "none"
    assert captured["messages"][0]["role"] == "user"
    assert captured["messages"][0]["content"].startswith("Extract the incident.")
    assert "Output contract:" in captured["messages"][0]["content"]
    assert payload.classification.issue_category == "STORE_TAX_ISSUE"
    assert metrics["provider"] == "lmstudio"
    assert metrics["total_tokens"] == 30


def test_lmstudio_health_reports_loaded_model(tmp_path, monkeypatch):
    config = settings(
        tmp_path,
        MODEL_PROVIDER="lmstudio",
        MODEL_NAME="nuextract3",
        LMSTUDIO_MODEL="nuextract3",
    )
    monkeypatch.setattr(
        "bi_mars.lmstudio.requests.get",
        lambda *args, **kwargs: FakeResponse({"data": [{"id": "nuextract3"}]}),
    )

    health = LMStudioClient(config).health()

    assert health.reachable is True
    assert health.model_available is True
    assert health.provider == "lmstudio"
