from __future__ import annotations

from dataclasses import dataclass
import time

import pytest

from bi_mars.freshservice import FreshserviceClient, FreshserviceHttpError, ticket_source_documents
from bi_mars.text import clean_html, extract_json_object

from .helpers import context, settings


def test_clean_html_preserves_text_and_removes_active_content():
    value = clean_html("<p>Hello<br>world</p><script>secret()</script><p>Next</p>")
    assert value == "Hello\nworld\nNext"


def test_extract_json_object_accepts_fenced_response():
    assert extract_json_object("```json\n{\"ok\": true}\n```") == {"ok": True}


@dataclass
class FakeResponse:
    status_code: int
    body: dict
    headers: dict[str, str] | None = None
    content: bytes = b""

    def json(self):
        return self.body

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(self.status_code)


class FakeSession:
    def __init__(self, responses):
        self.responses = list(responses)
        self.auth = None
        self.headers = {}
        self.calls = []

    def get(self, url, params=None, timeout=None):
        self.calls.append((url, params, timeout))
        return self.responses.pop(0)


def test_freshservice_retrieves_ticket_and_paginated_conversations(tmp_path):
    ticket_response = FakeResponse(
        200,
        {
            "ticket": {
                "id": 55,
                "display_id": "INC-55",
                "subject": "Synthetic",
                "description": "<p>Hello</p>",
                "description_text": "Hello",
                "requester": {"name": "Manager", "email": "sm4812@michaels.com"},
                "custom_fields": {"business_date": "2026-10-28"},
            }
        },
    )
    conversations_response = FakeResponse(
        200,
        {
            "conversations": [
                {"body": "<p>Later reply</p>", "created_at": "2026-10-28T02:00:00Z"},
                {"body": "<p>Initial reply</p>", "created_at": "2026-10-28T01:00:00Z"},
            ]
        },
        headers={},
    )
    session = FakeSession([ticket_response, conversations_response])
    client = FreshserviceClient(settings(tmp_path, MAX_RETRIES=0), session=session)
    loaded = client.get_context("55", deadline=time.monotonic() + 10)
    assert loaded.ticket["id"] == 55
    assert loaded.conversations[0]["body"].startswith("<p>")
    assert session.auth == ("synthetic-secret", "X")
    assert session.calls[0][0].endswith("/api/v2/tickets/55")
    assert session.calls[1][0].endswith("/api/v2/tickets/55/conversations")
    assert loaded.conversations[0]["body"] == "<p>Initial reply</p>"
    documents = ticket_source_documents(loaded)
    assert any(item["source"] == "custom_field" for item in documents)
    conversation_document = next(
        item for item in documents if item["source"] == "conversation"
    )
    assert "Conversation message 1 (chronological order)" in conversation_document["text"]
    assert "Created: 2026-10-28T01:00:00Z" in conversation_document["text"]
    assert "Message:\nInitial reply" in conversation_document["text"]


def test_freshservice_fetches_all_conversation_pages(tmp_path):
    ticket_response = FakeResponse(
        200,
        {
            "ticket": {
                "id": 55,
                "subject": "Pick list issue",
                "description_text": "The pick list is stuck.",
            }
        },
    )
    first_page = FakeResponse(
        200,
        {"conversations": [{"body": f"message-{index}"} for index in range(100)]},
        headers={"Link": '<https://synthetic.freshservice.test?page=2>; rel="next"'},
    )
    second_page = FakeResponse(
        200,
        {"conversations": [{"body": "final confirmation with LIST ID LST000000782176"}]},
        headers={},
    )
    session = FakeSession([ticket_response, first_page, second_page])
    client = FreshserviceClient(
        settings(tmp_path, MAX_RETRIES=0, MAX_CONVERSATION_PAGES=100),
        session=session,
    )

    loaded = client.get_context("55", deadline=time.monotonic() + 10)

    assert loaded.conversations_complete is True
    assert len(loaded.conversations) == 101
    assert loaded.conversations[-1]["body"].endswith("LST000000782176")
    assert session.calls[2][1]["page"] == 2


def test_freshservice_authentication_failure_is_transparent(tmp_path):
    session = FakeSession([FakeResponse(401, {"message": "bad credentials"})])
    client = FreshserviceClient(settings(tmp_path, MAX_RETRIES=0), session=session)
    with pytest.raises(FreshserviceHttpError) as error:
        client.get_ticket("55")
    assert error.value.code == "FRESHSERVICE_AUTHENTICATION_FAILED"


def test_freshservice_downloads_ticket_attachments_read_only(tmp_path):
    ticket_response = FakeResponse(
        200,
        {
            "ticket": {
                "id": 55,
                "subject": "Screenshot evidence",
                "description_text": "Please inspect the screenshot.",
                "attachments": [
                    {
                        "id": 9,
                        "name": "evidence.png",
                        "content_type": "image/png",
                        "attachment_url": "https://synthetic.freshservice.test/api/v2/attachments/9",
                    }
                ],
            }
        },
    )
    conversations_response = FakeResponse(200, {"conversations": []}, headers={})
    attachment_response = FakeResponse(200, {}, headers={"Content-Type": "image/png"}, content=b"png")
    session = FakeSession([ticket_response, conversations_response, attachment_response])

    loaded = FreshserviceClient(settings(tmp_path, MAX_RETRIES=0), session=session).get_context(
        "55",
        deadline=time.monotonic() + 10,
    )

    assert len(loaded.attachments) == 1
    assert loaded.attachments[0].filename == "evidence.png"
    assert loaded.attachments[0].data == b"png"
    assert session.calls[2][0].endswith("/api/v2/attachments/9")


def test_freshservice_does_not_cache_ticket_or_attachment_bytes(tmp_path):
    ticket_response = FakeResponse(
        200,
        {
            "ticket": {
                "id": 55,
                "description_text": "Attachment cache test",
                "attachments": [
                    {
                        "id": 9,
                        "name": "evidence.png",
                        "content_type": "image/png",
                        "attachment_url": "https://synthetic.freshservice.test/api/v2/attachments/9",
                    }
                ],
            }
        },
    )
    conversations_response = FakeResponse(200, {"conversations": []}, headers={})
    attachment_response = FakeResponse(200, {}, headers={"Content-Type": "image/png"}, content=b"png")
    second_ticket_response = FakeResponse(
        200,
        {
            "ticket": {
                "id": 55,
                "description_text": "Attachment cache test",
                "attachments": [
                    {
                        "id": 9,
                        "name": "evidence.png",
                        "content_type": "image/png",
                        "attachment_url": "https://synthetic.freshservice.test/api/v2/attachments/9",
                    }
                ],
            }
        },
    )
    second_conversations_response = FakeResponse(200, {"conversations": []}, headers={})
    second_attachment_response = FakeResponse(
        200,
        {},
        headers={"Content-Type": "image/png"},
        content=b"png-again",
    )
    session = FakeSession(
        [
            ticket_response,
            conversations_response,
            attachment_response,
            second_ticket_response,
            second_conversations_response,
            second_attachment_response,
        ]
    )
    client = FreshserviceClient(settings(tmp_path, MAX_RETRIES=0), session=session)

    first = client.get_context("55", deadline=time.monotonic() + 10)
    second = client.get_context("55", deadline=time.monotonic() + 10)

    assert first.attachments[0].data == b"png"
    assert second.attachments[0].data == b"png-again"
    assert not hasattr(client, "_cache")
    assert len(session.calls) == 6


def test_freshservice_normalizes_incident_reference_without_faking_ids(tmp_path):
    ticket_response = FakeResponse(
        200,
        {"ticket": {"id": 55, "subject": "Synthetic", "description_text": "Text"}},
    )
    session = FakeSession([ticket_response])
    client = FreshserviceClient(settings(tmp_path, MAX_RETRIES=0), session=session)
    ticket = client.get_ticket("INC-55")
    assert ticket["id"] == 55
    assert session.calls[0][0].endswith("/api/v2/tickets/55")


def test_freshservice_normalizes_service_request_reference(tmp_path):
    ticket_response = FakeResponse(
        200,
        {"ticket": {"id": 836061, "subject": "Synthetic service request"}},
    )
    session = FakeSession([ticket_response])
    client = FreshserviceClient(settings(tmp_path, MAX_RETRIES=0), session=session)

    ticket = client.get_ticket("SR-836061")

    assert ticket["id"] == 836061
    assert session.calls[0][0].endswith("/api/v2/tickets/836061")


def test_freshservice_rate_limit_is_reported_after_bounded_retry(tmp_path):
    session = FakeSession([FakeResponse(429, {}), FakeResponse(429, {})])
    client = FreshserviceClient(settings(tmp_path, MAX_RETRIES=1, RETRY_BACKOFF_SECONDS=0), session=session)
    with pytest.raises(FreshserviceHttpError) as error:
        client.get_ticket("55")
    assert error.value.code == "FRESHSERVICE_RATE_LIMITED"
    assert len(session.calls) == 2
